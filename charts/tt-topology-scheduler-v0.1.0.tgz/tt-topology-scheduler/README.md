# tt-topology-scheduler Helm Chart

Installs a **second kube-scheduler** carrying the `TTTopologyPlacement` plugin. TT
gang pods opt in with `spec.schedulerName: tt-topology-scheduler`; everything else
stays on the cluster's default scheduler.

This chart is **self-contained**: it installs standalone, with no `tt-mif` umbrella.
It is also consumed as a subchart by the `tt-mif` umbrella — both paths render the
same objects.

> **Install is one command.** With the generator switched on, Helm builds the cabling
> map from Fabric Manager *first* and only then starts the scheduler — so it comes up
> clean, with zero restarts. If Fabric Manager cannot be reached, the install itself
> fails, in your terminal, with the reason. (Changed 2026-09-04; before that a fresh
> install crash-looped until the map existed.)

---

## What the chart manages

| Resource | Kind | Namespace |
|---|---|---|
| `tt-scheduler` | Namespace | — |
| `tt-topology-scheduler` | ServiceAccount | tt-scheduler |
| `tt-topology-scheduler-config` | ConfigMap (`KubeSchedulerConfiguration`) | tt-scheduler |
| `tt-topology-scheduler` | ClusterRole | — |
| `tt-topology-scheduler-kube` | ClusterRoleBinding (`system:kube-scheduler`) | — |
| `tt-topology-scheduler-volume` | ClusterRoleBinding (`system:volume-scheduler`) | — |
| `tt-topology-scheduler-extra` | ClusterRoleBinding (own leader-election lease) | — |
| `tt-topology-scheduler-authreader` | RoleBinding (`extension-apiserver-authentication-reader`) | **kube-system** |
| `tt-topology-scheduler` | Deployment | tt-scheduler |
| `tt-fabric-topology` | ConfigMap (the cabling map) | tt-scheduler |

A second scheduler needs **all three** of `system:kube-scheduler`,
`system:volume-scheduler` and its own lease RBAC — plus the `kube-system`
authreader RoleBinding — or it will start and then fail on its first pod.

With `topologyGenerator.enabled=true` the chart adds a Job, ServiceAccount, Role and
RoleBinding named `tt-topology-scheduler-topology-gen`, all as **pre-install /
pre-upgrade hooks**: Helm creates them first and waits for the Job before it touches
the Deployment.

---

## Before you install

The scheduler needs three things in place. Each check below shows what "healthy"
looks like (output from a 4-Galaxy cluster, machine names and addresses anonymised;
yours will differ).

### 1. Kubernetes v1.35.x

```bash
kubectl version | grep -i server
```

```
Server Version: v1.35.4
```

The plugin is compiled against the v1.35.4 scheduler framework (KEP-4262 moved it
to `k8s.io/kube-scheduler/framework`). A different minor will not load — the
container starts and exits immediately.

### 2. `tt-dra-plugin` running — one ResourceSlice per Galaxy

The scheduler learns which machines have Tenstorrent devices, and of which model,
from the **DRA ResourceSlice device attributes** the plugin publishes
(`tenstorrent.com/model`). *Not a Helm dependency — a data prerequisite.*

```bash
kubectl get resourceslice
kubectl get deviceclass
```

```
NAME                                NODE          DRIVER            POOL          AGE
galaxy-01-tenstorrent.com-8sh86     galaxy-01     tenstorrent.com   galaxy-01     16m
galaxy-02-tenstorrent.com-fhcfq     galaxy-02     tenstorrent.com   galaxy-02     15m
…  one row per Galaxy  …

NAME              AGE
tenstorrent.com   9d
```

Without the slices the scheduler starts, wins leader election, and places
**nothing** — it sees no hosts. The device class to request is `tenstorrent.com`;
some clusters still show a retired `wormhole.tenstorrent.com`, which matches nothing.

### 3. Fabric Manager reachable — for the map

The scheduler places from a static cabling map and never talks to Fabric Manager
itself. But the map is *built* from Fabric Manager, by the generator Job, so FM must
be reachable at install time (and again whenever you rebuild the map). Find its
controller service and note the address — `<name>.<namespace>.svc.cluster.local:50052`:

```bash
kubectl get svc -A | grep -i fabric-manager
```

```
mif   tt-mif-tt-fabric-manager-controller   ClusterIP   10.x.x.x    50052/TCP   40d
mif   tt-mif-tt-fabric-manager-agent        ClusterIP   10.x.x.x    50053/TCP   40d
```

Port `50052` is the controller's always-on gRPC port, not the web UI. On MIF
clusters FM is part of the platform. The chart has **no default** for this address
on purpose: the service name depends on how FM was installed.

### 4. Credentials for the image registry

The default image lives in Moreh's internal ECR, which is not anonymously pullable.
On MIF clusters the pull secret already exists and is kept fresh by the umbrella's
ECR token refresher:

```bash
kubectl -n mif get secret moreh-registry
```

Copy it into your target namespace (below), or create a `docker-registry` secret,
or — the usual answer for air-gapped sites — mirror the image into the in-cluster
registry and override `image.repository` / `image.tag`.

---

## Install — standalone

### Pick the shelf and the version

| shelf | address | what is on it |
|---|---|---|
| **public** — for customers | `https://moreh-dev.github.io/helm-charts` (source: `github.com/moreh-dev/helm-charts`) | stable releases, e.g. `v0.1.0` |
| **stage** — Moreh internal | `https://artifact-keeper.master.moreh.dev/helm/charts` | release candidates, e.g. `v0.1.0-rc.2`, *and* the stable releases |

```bash
# customer, stable release:
export TTS_REPO=https://moreh-dev.github.io/helm-charts
export TTS_VERSION=v0.1.0

# or, Moreh internal / release candidate:
export TTS_REPO=https://artifact-keeper.master.moreh.dev/helm/charts
export TTS_VERSION=v0.1.0-rc.2

helm repo add tts-shelf $TTS_REPO && helm repo update tts-shelf
helm search repo tts-shelf/tt-topology-scheduler --versions --devel   # --devel: show rc's too
```

```
NAME                            CHART VERSION  APP VERSION  DESCRIPTION
tts-shelf/tt-topology-scheduler v0.1.0-rc.2    v0.1.0-rc.2  Second kube-scheduler with the TTTopologyPlacem...
```

### Namespace and pull credential

`TTS` is the release name **and** the scheduler's name; `TTS_NS` its namespace.

```bash
export TTS=tt-topology-scheduler        # or any name; gang pods will use it as schedulerName
export TTS_NS=tt-scheduler
kubectl create ns $TTS_NS
```

The namespace **must exist before the install** and the install **must** pass
`createNamespace=false`: the generator runs as a pre-install hook, and hooks are
created before every regular resource — including the chart's own Namespace. (The
chart refuses to render otherwise, with this explanation.)

On a MIF cluster the pull secret is **replicated, not copied**. The umbrella runs a
6-hourly job that mints a fresh ~12-hour ECR token into `moreh-registry` and fans it
out to every namespace labelled `mif=enabled`. Label yours and the secret arrives —
and stays fresh:

```bash
kubectl label ns $TTS_NS mif=enabled --overwrite
until kubectl -n $TTS_NS get secret moreh-registry >/dev/null 2>&1; do sleep 2; done
kubectl -n $TTS_NS get secret moreh-registry
```

```
NAME             TYPE                             DATA   AGE
moreh-registry   kubernetes.io/dockerconfigjson   1      3s
```

> Do **not** copy the secret by hand (`kubectl get secret … | kubectl apply`). A copy is
> frozen: the token inside expires within ~12 hours, and the next pod restart lands in
> `ImagePullBackOff` while the umbrella's own copy still works — it looks like a chart
> bug and is not.
>
> Not a MIF cluster? Create a `docker-registry` secret named `moreh-registry` yourself,
> or mirror the image and set `image.repository`/`image.tag`.

### The one command

```bash
helm install $TTS tts-shelf/tt-topology-scheduler --version $TTS_VERSION --devel \
  -n $TTS_NS \
  --set namespace=$TTS_NS --set fullnameOverride=$TTS --set createNamespace=false \
  --set imagePullSecrets[0].name=moreh-registry \
  --set topologyGenerator.enabled=true \
  --set topologyGenerator.fmControllerAddr=tt-mif-tt-fabric-manager-controller.mif.svc.cluster.local:50052
```

Helm pauses a few seconds while the map is built, then:

```
NAME: tt-topology-scheduler
NAMESPACE: tt-scheduler
STATUS: deployed
REVISION: 1
```

| flag | why |
|---|---|
| `fullnameOverride=$TTS` | **becomes the `schedulerName`** gang pods must use. Also keeps this install apart from any other scheduler on the cluster |
| `namespace=$TTS_NS` | where the objects go; must match the leader-election namespace, which is why the chart takes it as a value, not from `-n` |
| `createNamespace=false` | **required with the generator on a first install** — hooks run before the chart's Namespace would be created |
| `topologyGenerator.enabled=true` + `fmControllerAddr` | build the map **before** the scheduler starts (hook). Required on a first install unless you supply `fabricTopology.inline` |
| `--devel` | lets Helm see release candidates; harmless with a stable version |

Prefer a values file? `values-standalone.yaml.example` next to this README holds the
same settings with the two required lines marked; copy it, fill them, and pass `-f`.

### Expected result

Captured 2026-09-04 on a 4-Galaxy cluster, installed as `tts-hook` (so pod names
read `tts-hook-…`; with the default name they read `tt-topology-scheduler-…`).

The instant `helm install` returns — the map-builder has **already finished**, and
the scheduler is **only now** being created. That order is the whole point:

```bash
kubectl -n $TTS_NS get pods
```

```
NAME                          READY   STATUS              RESTARTS   AGE
tts-hook-6949fdcf95-w9frc     0/1     ContainerCreating   0          0s
tts-hook-topology-gen-mhpjq   0/1     Completed           0          4s
```

A few seconds later:

```
NAME                          READY   STATUS      RESTARTS   AGE
tts-hook-6949fdcf95-w9frc     1/1     Running     0          2s
tts-hook-topology-gen-mhpjq   0/1     Completed   0          6s
```

`Running` with **`RESTARTS 0`** — it started once and stayed up. The `Completed` row
is the map-builder; it finished before the scheduler existed.

What the map-builder did:

```bash
kubectl -n $TTS_NS logs job/$TTS-topology-gen
```

```
FM: 4 host(s), 128 asic(s), descriptor 44194 bytes
descriptor: 4 host(s) all discovered via UMD; JSON 188707 bytes, gzipped 8298 bytes (0.8% of the 1 MiB ConfigMap limit)
patched ConfigMap tts-hook/tt-fabric-topology
```

And the two lines that say the scheduler is **ready to work**, not merely running
(both printed once, at startup — read the whole log, no `--tail`):

```bash
kubectl -n $TTS_NS logs deploy/$TTS | grep -iE "fabric: lattice|acquired lease"
```

```
deps.go:107] fabric: lattice with 4 chassis, axes=[col] period=[4] wraps=[false]
leaderelection.go:272] "Successfully acquired lease" lock="tts-hook/tts-hook"
```

| line | meaning |
|---|---|
| `fabric: lattice with 4 chassis …` | **"I read your map and understood it."** Here: 4 machines cabled in a line, no loop back. Yours will describe *your* cabling |
| `Successfully acquired lease` | **"I am the one in charge."** A scheduler may run as several copies; only one may decide at a time. They hold an election, the winner takes a lease. This copy won |

Without the first it does not know how your machines connect; without the second it
sits quietly and places nothing.

### If the install fails

Because the map-builder runs first, a problem shows up **in the install itself**,
not later as a crash-loop:

```
Error: INSTALLATION FAILED: failed pre-install: job tt-topology-scheduler-topology-gen failed
```

The reason is in the Job's own words:

```bash
kubectl -n $TTS_NS logs job/$TTS-topology-gen
```

| it says | meaning | fix |
|---|---|---|
| `FM QueryPhysicalTopology failed at <addr>: rpc error: code = Unavailable …` | wrong address, or Fabric Manager not running | check `kubectl get svc -A \| grep fabric-manager`; fix `fmControllerAddr` |
| `REFUSING (no-fallback policy): discovery is degraded on …` | a device was busy, so FM's view was incomplete. The Job refuses to write a half-answer — a partial map is worse than none | free the devices, retry |

Retry with the same command after `helm uninstall $TTS -n $TTS_NS`. No scheduler
was created, so there is nothing half-working to clean up. **Read the log within an
hour** — the Job (and its log) is garbage-collected after `ttlSecondsAfterFinished`
(default 3600 s), failed or not.

**If anything named `$TTS` already exists on the cluster**, Helm refuses to adopt
objects it does not own — *"exists and cannot be imported into the current
release"*. Find out who owns it first:

```bash
kubectl -n $TTS_NS get deploy $TTS \
  -o jsonpath='{.metadata.annotations.meta\.helm\.sh/release-name}{"\n"}'
```

- **Empty, but the namespace exists** — created by hand; `createNamespace=false`
  (already in the command above) is the answer.
- **A release name comes back** (typically `tt-mif`) — the umbrella owns this
  scheduler, including the cluster-scoped ClusterRole and bindings. Do **not** install
  standalone beside it; either keep using the umbrella, or disable its copy first
  (`--set tt-topology-scheduler.enabled=false` on the umbrella).

### From a source checkout

```bash
helm lint     helm/tt-topology-scheduler
helm template tts helm/tt-topology-scheduler --set topologyGenerator.enabled=true \
  --set topologyGenerator.fmControllerAddr=<fm>:50052            # render first
helm install  tts helm/tt-topology-scheduler … --set image.tag=<a published tag>
```

The committed chart version is the sentinel `0.0.0` and the default image tag follows
it, so from a checkout you **must** set `image.tag` — `:0.0.0` was never built.

### As part of the tt-mif umbrella

The umbrella installs this chart under the `tt-topology-scheduler.*` values key and
supplies the FM address by default (`deploy/helm/tt-mif/` in the tt-mif repo).

**Do not enable the generator on a fresh umbrella install.** Subchart hooks run before
*any* regular resource of *any* subchart — so on a fresh install Fabric Manager (a
sibling subchart) does not exist yet, the pull secret has not been minted yet, and
the hook would fail the **whole** umbrella install. Install the umbrella with the
generator off (the default), then build the map in a follow-up upgrade once FM is up:

```bash
helm upgrade tt-mif … --reuse-values \
  --set tt-topology-scheduler.topologyGenerator.enabled=true      # runs as pre-upgrade hook
helm upgrade tt-mif … --reuse-values \
  --set tt-topology-scheduler.topologyGenerator.enabled=false     # and switch it off again
```

---

## Prove it works

The component ships a placement test: `test/README.md` in this repository. It
assumes the scheduler is installed as above, checks it is ready, then runs two
tests — independent single-Galaxy pods, and two 2-machine gangs that must each land
on a cabled pair — and prints a verdict against *your* cabling.

---

## The cabling map is load-bearing

`tt-fabric-topology` is the **sole** source of truth for which machines are wired
together. The placer trusts it completely; there is no cross-check at schedule time.
An edge that does not physically exist installs cleanly, schedules cleanly, and then
fails inside the engine as a fabric error — late, and pointing at the wrong component.

**Exactly one format is accepted: a PhysicalSystemDescriptor as JSON, optionally
gzipped.** The old two-column `hostA hostB` edge list is **rejected at startup**
(*"is not a PhysicalSystemDescriptor … no longer supported"*). Deliberate: an edge
list cannot distinguish a mesh concatenation from an arbitrary connection, so a 2×2
request on a 4-chassis ring used to be accepted against hardware with no second host
axis (`pkg/topologyplacement/deps.go`).

A descriptor is ~190 KB of JSON, so **the generator Job is the only realistic way to
produce one.** `fabricTopology.inline` exists to pin a known-good descriptor, not to
hand-write a map; the chart refuses to render if it does not start with `{`.

### Rebuilding the map later (re-cabling, a moved machine)

**Devices must be IDLE** — FM needs a full discovery, and the Job refuses to write a
degraded one. The generator runs as a *pre-upgrade* hook, and the same upgrade rolls
the scheduler pod (it carries a per-revision annotation while the generator is on),
so the rebuilt map is picked up without a manual restart:

```bash
helm upgrade $TTS tts-shelf/tt-topology-scheduler --version $TTS_VERSION --devel \
  -n $TTS_NS --reuse-values \
  --set topologyGenerator.enabled=true \
  --set topologyGenerator.fmControllerAddr=<fm-controller>:50052
kubectl -n $TTS_NS logs job/$TTS-topology-gen
```

**Then switch it off.** `--reuse-values` keeps `enabled=true`, so every later upgrade —
even a routine image bump — would re-run the generator and fail when devices are busy:

```bash
helm upgrade $TTS tts-shelf/tt-topology-scheduler --version $TTS_VERSION --devel \
  -n $TTS_NS --reuse-values --set topologyGenerator.enabled=false
```

### Upgrading from a 0.1.x release

In `0.1.0`/`0.1.1` the generator objects were ordinary resources. On the first upgrade
to this version with the generator enabled, Helm runs the new hook Job and then
removes the old same-named Job/RBAC as "no longer in the chart" — the map is built
correctly, but the hook Job's log may be gone by the time you look. One-time only.

---

## Values

| Key | Default | What it does |
|---|---|---|
| `nameOverride` | `""` | Chart name override. |
| `fullnameOverride` | `""` | Full name override. **This is also the `schedulerName`** — change it and every gang pod must change with it. |
| `global.imagePullSecrets` | `[]` | Pull secrets shared with sibling subcharts under the umbrella. |
| `namespace` | `tt-scheduler` | Namespace for the scheduler, its RBAC, config and map. Must match the leader-election `resourceNamespace`. |
| `createNamespace` | `true` | Render the Namespace object. **Must be `false` on a first install with the generator on** (hooks run before it would exist); the chart refuses to render otherwise. |
| `image.repository` | `255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/tt-topology-scheduler` | The internal ECR. Holds both `/tt-topology-scheduler` and `/gen-fabric-topology`. ghcr is legacy. |
| `image.tag` | `""` | Empty ⇒ the chart's `appVersion` (stamped by CI at release; `0.0.0` in a checkout). A mutable tag such as `local` needs `pullPolicy: Always` — for the generator Job too. |
| `image.pullPolicy` | `IfNotPresent` | |
| `imagePullSecrets` | `[]` | Chart-local pull secrets; merged with `global.imagePullSecrets`. |
| `replicas` | `1` | Leader election means one is active; `>1` is warm standby. |
| `logLevel` | `"2"` | klog `--v`. `2` shows placement and gang decisions; `4` shows the free-set reasoning. |
| `resources` | `{}` | Requests/limits for the scheduler container. |
| `nodeSelector` / `tolerations` / `affinity` | `{}` / `[]` / `{}` | |
| `fabricTopology.create` | `true` | Render the `tt-fabric-topology` ConfigMap (pre-install hook, `resource-policy: keep`). Keep `true` — the scheduler hard-requires the file at boot. |
| `fabricTopology.inline` | `""` | A PhysicalSystemDescriptor JSON to pin. Must start with `{`; the legacy edge list is refused at render. Empty ⇒ populated by the generator. |
| `topologyGenerator.enabled` | `false` | Render the generator Job + its RBAC as **pre-install / pre-upgrade hooks**; while on, the scheduler pod is rolled every revision. Turn on for a first install and for deliberate rebuilds — and **off again afterwards** (it persists under `--reuse-values`). |
| `topologyGenerator.fmControllerAddr` | `""` | FM controller gRPC address (`:50052`). **Required when `enabled=true`; the chart refuses to render without it.** No default on purpose. |
| `topologyGenerator.backoffLimit` | `2` | |
| `topologyGenerator.activeDeadlineSeconds` | `120` | The longest a first install can wait on FM before failing. |
| `topologyGenerator.ttlSecondsAfterFinished` | `3600` | How long the finished Job — and its log, the only record of why an install failed — survives. |
| `rbac.create` | `true` | Create the ServiceAccount, ClusterRoles/Bindings and the `kube-system` authreader RoleBinding a second scheduler needs. |

Values carry `# --` doc comments in `values.yaml` in the `helm-docs` format; this
table is maintained by hand alongside them.

---

## Uninstall

```bash
helm uninstall $TTS -n $TTS_NS
kubectl delete clusterrole $TTS --ignore-not-found
kubectl delete clusterrolebinding $TTS-kube $TTS-volume $TTS-extra --ignore-not-found
kubectl delete rolebinding $TTS-authreader -n kube-system --ignore-not-found
kubectl delete ns $TTS_NS        # also removes the map and the hook objects
```

Two things survive a plain `helm uninstall` on purpose and are removed by the lines
above: the cluster-scoped RBAC after a *failed* install (Helm will not delete what it
does not think it created — the next install then fails with "already exists"), and
`tt-fabric-topology`, which carries `resource-policy: keep` because the map is
expensive to rebuild. Deleting the namespace also drops the `mif=enabled` label, so the
replicated secret stops arriving. Hook objects (the generator's Job and RBAC) are not tracked by
the release either; deleting the namespace takes them.

---

## See also

- `../../test/README.md` — prove the installed scheduler works on your cluster
- `../../DESIGN.md` — why a scheduler plugin, and the four constraints it satisfies
- `../../FM-FREE-PLACER.md` — the static-graph placer, and the topology lifecycle
- `../../README.md` — the component: build, deploy, validation history
