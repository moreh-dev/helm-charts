{{- define "norns.matchLabels" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "norns.labels" -}}
{{- range $name, $value := .Values.commonLabels -}}
{{ $name }}: {{ tpl $value $ }}
{{ end -}}
helm.sh/chart: {{ include "common.names.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- end }}
app.kubernetes.io/part-of: mif
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ include "norns.matchLabels" . }}
{{- end }}

{{- define "norns.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Convert matchLabels map to comma-separated key=value string
*/}}
{{- define "norns.matchLabelsToString" -}}
{{- $pairs := list -}}
{{- range $key := keys . | sortAlpha -}}
{{- $pairs = append $pairs (printf "%s=%s" $key (index $ $key)) -}}
{{- end -}}
{{- join "," $pairs -}}
{{- end -}}
