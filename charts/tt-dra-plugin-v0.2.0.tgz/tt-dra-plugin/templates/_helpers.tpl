{{/*
Full image reference, e.g. ghcr.io/org/tt-dra-plugin:sha-abc1234.
Tag defaults to the (CI-stamped) chart appVersion when image.tag is empty.
*/}}
{{- define "tt-dra-plugin.image" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{ .Values.image.repository }}:{{ $tag }}
{{- end }}

{{/*
Merged image pull secrets (chart-local + umbrella global). Renders the full
`imagePullSecrets:` block, or nothing when both are empty.
*/}}
{{- define "tt-dra-plugin.imagePullSecrets" -}}
{{- $secrets := concat (.Values.imagePullSecrets | default list) ((.Values.global).imagePullSecrets | default list) -}}
{{- if $secrets }}
imagePullSecrets:
{{- range $secrets }}
- {{ toYaml . | nindent 2 | trim }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Vendor domain — the single identity the whole chart + plugin keys off.
Precedence: config.vendor -> global.vendor (umbrella) -> "tenstorrent"
Unknown values fail the render loudly rather than shipping a broken DeviceClass.
*/}}
{{- define "tt-dra-plugin.vendorDomain" -}}
{{- $v := .Values.config.vendor | default .Values.global.vendor | default "tenstorrent" -}}
{{- if eq $v "tenstorrent" -}}tenstorrent.com
{{- else if eq $v "jizhou" -}}jizhou.ambreai.com
{{- else -}}{{ fail (printf "config.vendor / global.vendor must be 'tenstorrent' or 'jizhou', got %q" $v) }}
{{- end -}}
{{- end }}

{{/*
Plugin socket dir, derived from the vendor domain so it always equals the
driver name kubelet registers under.
*/}}
{{- define "tt-dra-plugin.socketDir" -}}
{{- if .Values.plugin.pluginDir }}{{ fail "plugin.pluginDir was removed: the socket dir is derived from config.vendor" }}{{ end -}}
/var/lib/kubelet/plugins/{{ include "tt-dra-plugin.vendorDomain" . }}
{{- end }}

{{/*
Common labels applied to every resource.
*/}}
{{- define "tt-dra-plugin.labels" -}}
app.kubernetes.io/name: tt-dra-plugin
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
{{- end }}
