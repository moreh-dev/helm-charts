# redis-sentinel

Self-contained Redis Sentinel HA chart for the Heimdall Responses API
tiered store (MAF-19708). One StatefulSet with sidecar redis-sentinel
containers, bootstrapped via init container scripts. No external
operator dependency. Uses docker.io/library/redis:8.0 (AGPLv3 OSI
open source).

## What this chart deploys

- `StatefulSet` with `replicas` (default 3), each pod running:
  - `redis` container — `redis-server /data/redis.conf`
  - `sentinel` container — `redis-sentinel /data/sentinel.conf`
  - `bootstrap` initContainer — writes redis.conf and sentinel.conf if missing
- `ConfigMap` — bootstrap.sh script
- `Service` (headless) — stable per-pod DNS, ports 6379 + 26379
- `Service` (ClusterIP) — sentinel:26379, the Heimdall plugin entry point
- `Secret` — root password (auto-generated unless overridden), only when `auth.enabled=true`

The init container is **idempotent**: on first boot it creates redis.conf
(pod-0 starts as master, pod-1+ start as replicas of pod-0) and
sentinel.conf (initial master pointer + standard timeouts). On
subsequent restarts, it preserves whatever sentinel has rewritten via
`CONFIG REWRITE` in `/data`. PVC is required and configured per pod.

## Prerequisites

- Kubernetes ≥ 1.27
- A `StorageClass` named `ceph-block` (or override `persistence.storageClassName`)

## Install

```bash
cd deploy/helm
helm install heimdall-redis ./redis-sentinel -n mif
```

After install, verify:

```bash
kubectl rollout status statefulset/heimdall-redis-redis-sentinel -n mif

# Sentinel sees the current master (returns host + port on two lines)
kubectl exec -n mif heimdall-redis-redis-sentinel-0 -c sentinel -- \
  redis-cli -p 26379 SENTINEL get-master-addr-by-name heimdall-redis
```

## Image and license

| Component | Image | License |
|-----------|-------|---------|
| Redis server / Sentinel | `docker.io/library/redis:8.0` (Docker Hub Official) | **AGPLv3** (OSI open source) |

Redis 8.0 returned to AGPLv3 in May 2025 — it is the first OSI-approved
Redis release since 7.2.x. AGPL obligations only trigger when the Redis
**source code is modified and exposed as a network service**; using the
unmodified container image as a backing store does not.

If a customer policy blocks AGPLv3 adoption entirely, override to the
RSALv2 / SSPLv1 source-available track (Redis 7.4):

```bash
helm install heimdall-redis ./redis-sentinel -n mif --set image.tag=7.4
```

No Bitnami images are used.

## Connecting from the Heimdall plugin

The chart exposes one `ClusterIP` Service for sentinel discovery:

| Service | Port | Use |
|---------|------|-----|
| `<release>-redis-sentinel` | 26379 | **Sentinel discovery (recommended)** |
| `<release>-redis-sentinel-headless` | 6379, 26379 | Per-pod DNS for debugging |

Plugin config:

```yaml
redis:
  addresses:
    - heimdall-redis-redis-sentinel.mif.svc.cluster.local:26379
  masterName: heimdall-redis
```

The plugin discovers the current master and replicas through sentinel.
No client-side master tracking is needed.

## Scaling

Scale up:

```bash
helm upgrade heimdall-redis ./redis-sentinel -n mif --set replicas=5
```

New pods bootstrap as replicas of pod-0. Sentinel auto-discovers them
via gossip. The `quorum` value is unchanged (default 2). To raise quorum
to 3 after scaling to 5:

```bash
kubectl exec -n mif heimdall-redis-redis-sentinel-0 -c sentinel -- \
  redis-cli -p 26379 SENTINEL SET heimdall-redis quorum 3
```

## Auth

Disabled by default. Enable for production hardening:

```bash
helm install heimdall-redis ./redis-sentinel -n mif \
  --set auth.enabled=true
```

The chart generates a 24-char random password and stores it in a
`<release>-redis-sentinel-auth` Secret (preserved across upgrades via
`lookup`). The init container plumbs it into `requirepass`/`masterauth`
in redis.conf and `sentinel auth-pass` in sentinel.conf.

To use an externally-managed Secret:

```bash
helm install heimdall-redis ./redis-sentinel -n mif \
  --set auth.enabled=true \
  --set auth.existingSecret=my-redis-secret
```

The Secret must contain a `password` key.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| auth | object | `{"enabled":false,"existingSecret":""}` | Auth configuration. Disabled by default (in-cluster + NetworkPolicy gate assumed); enable for production hardening or compliance. |
| auth.enabled | bool | `false` | Require AUTH on redis and sentinel. |
| auth.existingSecret | string | `""` | Externally-managed Secret with key `password`. If empty AND `auth.enabled` is true, the chart generates a 24-char random password (preserved across upgrades via lookup). |
| fullnameOverride | string | `""` | Full name override. |
| image | object | `{"pullPolicy":"IfNotPresent","registry":"docker.io","repository":"library/redis","tag":"8.0"}` | Container image. Default `docker.io/library/redis:8.0` (Docker Hub Official, AGPLv3). Override `tag` to `"7.4"` for RSALv2 source-available track if AGPL is blocked. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| image.registry | string | `"docker.io"` | Image registry. |
| image.repository | string | `"library/redis"` | Image repository. |
| image.tag | string | `"8.0"` | Image tag. `"8.0"` (AGPLv3) by default; `"7.4"` for RSALv2 escape hatch. |
| nameOverride | string | `""` | Chart name override. |
| persistence | object | `{"size":"8Gi","storageClassName":"ceph-block"}` | PVC configuration (per pod). Stores redis dump.rdb/AOF and sentinel.conf. |
| persistence.size | string | `"8Gi"` | PVC size per pod. |
| persistence.storageClassName | string | `"ceph-block"` | StorageClass for PVCs. |
| redis | object | `{"port":6379,"resources":{"limits":{"memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}}` | Redis server (data tier) configuration. |
| redis.port | int | `6379` | Redis port. |
| redis.resources | object | `{"limits":{"memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` | Redis container resource requests/limits. |
| replicas | int | `3` | Number of pods (== sentinel quorum members). Each pod runs one redis-server + one redis-sentinel sidecar. |
| sentinel | object | `{"downAfterMilliseconds":5000,"failoverTimeout":60000,"masterSet":"heimdall-redis","parallelSyncs":1,"port":26379,"quorum":2,"resources":{"limits":{"memory":"256Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}}` | Redis Sentinel (failover quorum) configuration. |
| sentinel.downAfterMilliseconds | int | `5000` | Milliseconds before sentinel declares master subjectively down. |
| sentinel.failoverTimeout | int | `60000` | Maximum time (ms) for a failover operation before sentinel aborts. |
| sentinel.masterSet | string | `"heimdall-redis"` | Sentinel masterName (the Heimdall plugin must use this value for sentinel discovery). |
| sentinel.parallelSyncs | int | `1` | Maximum number of replicas that can sync with the new master simultaneously after failover. |
| sentinel.port | int | `26379` | Sentinel port. |
| sentinel.quorum | int | `2` | Failover quorum (minimum sentinel agreement to declare master down). `2` of 3 replicas is the standard HA configuration. |
| sentinel.resources | object | `{"limits":{"memory":"256Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}` | Sentinel container resource requests/limits. |

## Migration from 0.2.0 (Spotahome RedisFailover)

Version `0.2.0` produced a Spotahome `databases.spotahome.com/v1`
`RedisFailover` CR. Version `0.3.0` is self-contained — no operator
dependency.

This is a **breaking change**. Map keys as follows:

| 0.2.0 key | 0.3.0 key |
|-----------|-----------|
| `redis.replicas` | `replicas` (single count, sentinel and redis 1:1) |
| `redis.resources` | `redis.resources` |
| `redis.storage.size` | `persistence.size` |
| `redis.storage.storageClassName` | `persistence.storageClassName` |
| `sentinel.replicas` | (removed; equals `replicas`) |
| `sentinel.quorum` | `sentinel.quorum` |
| `sentinel.masterSet` | `sentinel.masterSet` |
| `auth.enabled` | `auth.enabled` |
| `auth.existingSecret` | `auth.existingSecret` |
| `operatorAssumed` | (removed) |

Service names also change (operator-generated → chart-generated):

| 0.2.0 service | 0.3.0 service |
|---------------|---------------|
| `rfs-<release>` (sentinel) | `<release>-redis-sentinel` |
| `rfr-<release>` (read replicas) | (removed; sentinel discovery only) |
| `rf-<release>-master` (current master) | (removed; sentinel discovery only) |

Live data migration is not in scope. The chart 0.2.0 is assumed to be
not deployed in production; for new installs simply install 0.3.0
directly.

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
