# heimdall

![Version: 0.0.0](https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.0](https://img.shields.io/badge/AppVersion-0.0.0-informational?style=flat-square)

Heimdall; AI Gateway operator for MIF

**Homepage:** <https://github.com/moreh-dev/heimdall>

## Source Code

* <https://github.com/moreh-dev/heimdall/tree/main/deploy/helm/heimdall>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | common | 2.31.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity rules for pods scheduling. |
| aigateway.defaultRegistry | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com"` | Default image registry for AIGateway deployments. |
| aigateway.defaultTag | string | `"v0.3.0"` | Default image tag for AIGateway deployments. Override to pin a specific AIGateway version. |
| aigateway.dev.gateway | string | `"# NOTE: spec.image, spec.{extraArgs,extraEnvVars,resources,extraVolumes,\n# extraVolumeMounts}, spec.{nodeSelector,tolerations,affinity}, and\n# spec.updateStrategy are applied to the rendered template by the\n# controller (see internal/controller/aigateway_podtemplate_patch.go).\n# User entries override defaults by merge key (extraEnvVars and\n# extraVolumes by name, extraVolumeMounts by mountPath, resources per\n# resource name; extraArgs via flag-aware merge).\ndeployment:\n  spec:\n    template:\n      spec:\n        enableServiceLinks: false\n        containers:\n          - name: aigateway\n            args:\n              - --name\n              - \"{{ `{{ .AIGateway.Name }}` }}\"\n            env:\n              - name: AIGATEWAY_NAMESPACE\n                valueFrom:\n                  fieldRef:\n                    fieldPath: metadata.namespace\n              - name: AIGATEWAY_POD_IP\n                valueFrom:\n                  fieldRef:\n                    fieldPath: status.podIP\n              - name: AIGATEWAY_LOG_LEVEL\n                value: {{ .Values.telemetry.log.level | quote }}\n              - name: AIGATEWAY_LOG_FORMAT\n                value: {{ .Values.telemetry.log.format | quote }}\n              {{- with .Values.telemetry.trace.exporter.endpoint }}\n              - name: OTEL_EXPORTER_OTLP_TRACES_ENDPOINT\n                value: {{ . | quote }}\n              - name: OTEL_TRACES_SAMPLER\n                value: {{ $.Values.telemetry.trace.sampler.type | quote }}\n              - name: OTEL_TRACES_SAMPLER_ARG\n                value: {{ $.Values.telemetry.trace.sampler.argument | quote }}\n              {{- end }}\n            ports:\n              - containerPort: 8000\n                name: http\n              - containerPort: 15560\n                name: event-plane\n            readinessProbe:\n              httpGet:\n                path: /health\n                port: http\nservice:\n  spec:\n    ports:\n      - port: 8000\n        targetPort: 8000\n        name: http\nrbac:\n  rules:\n    - apiGroups: [\"discovery.k8s.io\"]\n      resources: [\"endpointslices\"]\n      verbs: [\"get\", \"list\", \"watch\"]\n    - apiGroups: [\"heimdall.moreh.io\"]\n      resources: [\"inferenceworkers\"]\n      verbs: [\"get\", \"list\", \"watch\"]\n  clusterRules:\n    - apiGroups: [\"heimdall.moreh.io\"]\n      resources: [\"schedulingprofiles\"]\n      verbs: [\"get\", \"list\", \"watch\"]\nserviceMonitor:\n  metadata:\n    labels:\n      {{- toYaml .Values.telemetry.metrics.labels | nindent 6 }}\n  spec:\n    endpoints:\n      - port: http\n        path: /metrics\n        interval: 15s\n        scrapeTimeout: 10s\n"` | Gateway configuration for the dev ConfigMap. Rendered through common.tplvalues.render at chart install time — expressions that target the controller's template engine (.AIGateway.*, with/end, etc.) must be escaped with raw string literals ({{ `{{ .X }}` }}), while expressions that target Helm ({{ .Values.* }}) are evaluated normally. |
| aigateway.dev.sidecar | string | `"# NOTE: the sidecar's image / imagePullPolicy and spec.sidecar.{extraArgs,\n# extraEnvVars,resources} are applied by the pod-sidecar webhook after\n# rendering this template (see ResolveSidecarImage and applySidecarOverlay\n# in internal/webhook/v1alpha1/pod_sidecar_webhook.go). image fields fall\n# back to the gateway image at render time when not set on the sidecar.\nrbac:\n  rules:\n    - apiGroups: [\"\"]\n      resources: [\"pods\"]\n      verbs: [\"get\"]\n    - apiGroups: [\"heimdall.moreh.io\"]\n      resources: [\"inferenceworkers\"]\n      verbs: [\"create\", \"get\", \"list\", \"patch\", \"update\", \"watch\"]\npodTemplate:\n  spec:\n    enableServiceLinks: false\n    initContainers:\n      - name: aigateway-sidecar\n        env:\n          - name: SIDECAR_POD_NAME\n            valueFrom:\n              fieldRef:\n                fieldPath: metadata.name\n          - name: SIDECAR_NAMESPACE\n            valueFrom:\n              fieldRef:\n                fieldPath: metadata.namespace\n        ports:\n          - containerPort: 15550\n            name: http\n          - containerPort: 15551\n            name: metrics-pub\n          - containerPort: 15552\n            name: kv-pub\n        restartPolicy: Always\n    containers:\n      - name: main\n        readinessProbe:\n          httpGet:\n            path: /health\n            port: 15550\npodMonitor:\n  metadata:\n    labels:\n      {{- toYaml .Values.telemetry.metrics.labels | nindent 6 }}\n  spec:\n    podMetricsEndpoints:\n      - port: http\n        path: /metrics\n        interval: 15s\n        scrapeTimeout: 10s\n"` | Sidecar configuration for the dev ConfigMap. Same Helm-vs-controller templating rules as `gateway` apply — escape .AIGateway.*, .Pod.*, and other controller-side expressions with raw string literals. |
| args | list | `[]` | Arguments to override the main container's default arguments. |
| command | list | `[]` | Command applied to the main container. If not set, the container's default command is used. |
| commonLabels | object | `{}` | Labels applied to all resources. |
| extraArgs | list | `["--zap-encoder=json","--zap-log-level=info"]` | Extra arguments added to the main container's default arguments. If `args` is set, this value is ignored. |
| fullnameOverride | string | `""` | Full name override. |
| global | object | `{"imagePullSecrets":[]}` | global values are shared across all sub-charts if the value's key matches. |
| global.imagePullSecrets | list | `[]` | Image pull secrets. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| image.pullSecrets | list | `[]` | Image pull secrets. |
| image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/heimdall"` | Image repository. |
| image.tag | string | `""` | Image tag (defaults to chart appVersion if not set). |
| nameOverride | string | `""` | Chart name override. |
| namespaceOverride | string | `""` | Namespace override. |
| namespaceSelector.matchLabels | object | `{}` | Label selector for namespace filtering (dev use). When set, Heimdall only watches namespaces with matching labels. Example: { "mif.moreh.io/heimdall": "<name>" } |
| nodeSelector | object | `{}` | Node selector for pods scheduling. |
| podAnnotations | object | `{}` | Annotations applied to all pods. |
| podLabels | object | `{}` | Labels applied to all pods. |
| replicas | int | `1` | Number of replicas. |
| resources | object | `{}` | Resource requests and limits for the main container. |
| serviceAccount.annotations | object | `{}` | Annotations added to the ServiceAccount. |
| serviceAccount.automount | bool | `true` | Whether to automatically mount API credentials. |
| serviceAccount.create | bool | `true` | Whether to create a ServiceAccount. |
| serviceAccount.name | string | `""` | Name of the ServiceAccount (auto-generated if empty and create is true). |
| telemetry.log.format | string | `"json"` | AIGateway log format. Rendered into AIGATEWAY_LOG_FORMAT. |
| telemetry.log.level | string | `"info"` | AIGateway log level. Rendered into AIGATEWAY_LOG_LEVEL. |
| telemetry.metrics.labels | object | `{}` | Labels added to the metadata of every ServiceMonitor and PodMonitor the controller creates. Set when Prometheus-Operator's `serviceMonitorSelector` / `podMonitorSelector` requires specific labels for scrape discovery (e.g. `release: kube-prometheus-stack`). |
| telemetry.trace.exporter.endpoint | string | `""` | OTLP traces endpoint. Rendered into OTEL_EXPORTER_OTLP_TRACES_ENDPOINT. When empty, trace env vars are omitted and tracing stays off. |
| telemetry.trace.sampler.argument | float | `0.05` | Trace sampler argument. Rendered into OTEL_TRACES_SAMPLER_ARG. |
| telemetry.trace.sampler.type | string | `"parentbased_traceidratio"` | Trace sampler type. Rendered into OTEL_TRACES_SAMPLER. |
| tolerations | list | `[]` | Tolerations for pods scheduling. |
| updateStrategy.type | string | `"RollingUpdate"` | Update strategy for deployment. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
