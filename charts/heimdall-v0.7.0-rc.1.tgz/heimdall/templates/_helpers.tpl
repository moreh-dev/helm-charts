{{- define "heimdall.matchLabels" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "heimdall.labels" -}}
{{- range $name, $value := .Values.commonLabels -}}
{{ $name }}: {{ tpl $value $ }}
{{ end -}}
helm.sh/chart: {{ include "common.names.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- end }}
app.kubernetes.io/part-of: mif
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ include "heimdall.matchLabels" . }}
{{- end }}

{{- define "heimdall.namespaceSelectorString" -}}
{{- $pairs := list -}}
{{- range $k := (keys .Values.namespaceSelector.matchLabels | sortAlpha) -}}
{{- $pairs = append $pairs (printf "%s=%s" $k (index $.Values.namespaceSelector.matchLabels $k)) -}}
{{- end -}}
{{- join "," $pairs -}}
{{- end -}}

{{- define "heimdall.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- /*
Labels for model-card-sync resources. app.kubernetes.io/name differs from the
operator's so the webhook Service selector never matches a sync pod.
*/}}
{{- define "heimdall.modelCardSync.labels" -}}
{{- range $name, $value := .Values.commonLabels -}}
{{ $name }}: {{ tpl $value $ }}
{{ end -}}
helm.sh/chart: {{ include "common.names.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- end }}
app.kubernetes.io/part-of: mif
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: {{ include "common.names.name" . }}-model-card-sync
app.kubernetes.io/instance: {{ .Release.Name }}
mif.moreh.io/component: model-card-sync
{{- end }}

{{/*
Name of the model-card-sync CronJob and its ServiceAccount and Secret. A
CronJob name caps at 52 characters, so the name is truncated to fit.
*/}}
{{- define "heimdall.modelCardSync.fullname" -}}
{{- printf "%s-model-card-sync" (include "common.names.fullname" .) | trunc 52 | trimSuffix "-" -}}
{{- end -}}
