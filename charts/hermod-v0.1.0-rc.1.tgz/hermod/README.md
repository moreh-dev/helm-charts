# hermod

Hermod - LLM artifact lifecycle operator for Kubernetes

![Version: 0.0.0](https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.0](https://img.shields.io/badge/AppVersion-0.0.0-informational?style=flat-square)

**Homepage:** <https://github.com/moreh-dev/hermod>

## Prerequisites

- Kubernetes 1.32+
- [cert-manager](https://cert-manager.io/) installed cluster-wide
- The `hermod-crd` chart installed first:

  ```
  helm upgrade -i hermod-crd deploy/helm/hermod-crd
  ```

## Install

```
helm dependency update deploy/helm/hermod
helm upgrade -i hermod deploy/helm/hermod \
  --namespace hermod-system --create-namespace
```

The operator detects its install namespace at runtime via the Downward API
(`POD_NAMESPACE`); you may install into any namespace, and all generated
resources (origin PVCs, download Jobs, mirror Secrets) are placed there.
`spec.persistentVolumeClaimRef` on an `ArtifactRepository` must reference a
PVC in that same install namespace.

## HuggingFace token (private models)

Create a Kubernetes Secret first, then reference it from
`downloader.hf.defaultEnvVars` so every HF Job inherits the token as a
default. Per-Artifact `spec.source.huggingface.tokenSecretRef` overrides
this when set.

```
kubectl -n hermod-system create secret generic hf-token \
  --from-literal=HF_TOKEN=<hf_xxx>

helm upgrade hermod deploy/helm/hermod \
  --namespace hermod-system --reuse-values --values - <<VALUES
downloader:
  hf:
    defaultEnvVars:
      - name: HF_TOKEN
        valueFrom:
          secretKeyRef:
            name: hf-token
            key: HF_TOKEN
VALUES
```

If the whole Secret should be injected as-is, use the `envFrom` shortcut:

```
helm upgrade hermod deploy/helm/hermod \
  --namespace hermod-system --reuse-values \
  --set downloader.hf.defaultEnvVarsSecret=hf-token
```

## Migration from pre-0.1 (monolithic chart)

| Old key                                   | New key                                            |
|-------------------------------------------|----------------------------------------------------|
| `manager.replicas`                        | `controller.replicas`                              |
| `manager.image.*`                         | `controller.image.*` (`pullSecrets` added)         |
| `manager.args`                            | `controller.args` / `controller.extraArgs`         |
| `manager.env` + `manager.envOverrides`    | `controller.extraEnvVars` (supports `valueFrom`)   |
| `manager.imagePullSecrets`                | `controller.image.pullSecrets`, `global.imagePullSecrets` |
| `manager.resources/nodeSelector/...`      | `controller.resources/nodeSelector/...`            |
| `controller.downloaderImage.*`            | `downloader.image.*`                               |
| `controller.maxConcurrentDownloads`       | `downloader.maxConcurrentDownloads`                |
| `controller.downloadBandwidthLimit`       | `downloader.bandwidthLimit`                        |
| `controller.huggingface.defaultEnv` (map) | `downloader.hf.defaultEnvVars` (list of EnvVar, supports `valueFrom`) |
| `rbacHelpers.enable`                      | `rbacHelpers.enabled`                              |
| `crd.enable`, `crd.keep`                  | removed — install `hermod-crd` separately          |
| `metrics.enable`, `metrics.port`          | removed — metrics always on port 8443              |
| `certManager.enable`                      | removed — cert-manager must be pre-installed       |
| `webhook.enable/port/caBundle/certSecret` | removed — webhook is always on port 9443 (cert-manager-managed) |
| `serviceMonitor.enable`                   | `controller.metrics.serviceMonitor.enabled`        |

CRD schema: `spec.existingPvcRef` has been renamed to
`spec.persistentVolumeClaimRef`. Update existing `ArtifactRepository`
manifests accordingly.

### New keys in 0.1

The chart exposes two families of env-injection knobs:

| Key                                   | Scope                          | Priority              |
|---------------------------------------|--------------------------------|-----------------------|
| `downloader.extraEnvVars` (list)      | ALL downloader Jobs (HF, S3, check, cleanup) | OVERRIDE (bitnami convention — wins over per-Artifact) |
| `downloader.extraEnvVarsSecret` (str) | ALL downloader Jobs            | envFrom (K8s-native low priority) |
| `downloader.hf.defaultEnvVars` (list) | HF download / validation Jobs only | DEFAULT (per-Artifact `spec.source.huggingface.env` / `tokenSecretRef` overrides) |
| `downloader.hf.defaultEnvVarsSecret` (str) | HF download / validation Jobs only | envFrom (K8s-native low priority) |

Typical patterns:

- Cluster-wide HuggingFace mirror with per-Artifact escape hatch:
  set `downloader.hf.defaultEnvVars: [{name: HF_ENDPOINT, value: https://mirror}]`.
- Shared fallback HF token that per-Artifact `tokenSecretRef` may override:
  set `downloader.hf.defaultEnvVars: [{name: HF_TOKEN, valueFrom: {secretKeyRef: {name: ..., key: HF_TOKEN}}}]`.
- Admin-enforced value that users cannot override: set `downloader.extraEnvVars`.

Inline `value: "<secret>"` literals end up in Helm release history —
prefer `valueFrom.secretKeyRef` for credentials.

Controller-managed keys (`HF_HOME`, `REPO_ID`, `MODEL_ID`, `REVISION`,
`ARTIFACT_DIR`, `ARTIFACT_NAME`, `S3_*`) are reserved: setting them in
`extraEnvVars` or `hf.defaultEnvVars` makes `helm install/upgrade` fail
with a clear error. The operator also rejects them on startup as a
runtime safety net.

When both `extraEnvVarsSecret` and `hf.defaultEnvVarsSecret` are set,
`extraEnvVarsSecret` wins for duplicate keys (it is applied later in
the Pod's `envFrom` list).

## Requirements

Kubernetes: `>= 1.32.0-0`

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | common | 2.31.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| commonLabels | object | `{}` | Labels applied to every resource produced by the chart. |
| controller | object | `{"affinity":{},"args":[],"command":[],"extraArgs":[],"extraEnvVars":[],"extraVolumeMounts":[],"extraVolumes":[],"image":{"pullPolicy":"IfNotPresent","pullSecrets":[],"repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod","tag":""},"metrics":{"serviceMonitor":{"enabled":false,"interval":"","labels":{}}},"nodeSelector":{},"podAnnotations":{},"podLabels":{},"replicas":1,"resources":{},"tolerations":[],"updateStrategy":{"type":"RollingUpdate"}}` | Controller-manager (operator) deployment configuration. |
| controller.affinity | object | `{}` | Affinity rules for operator pod scheduling. |
| controller.args | list | `[]` | download-bandwidth-limit=<downloader.bandwidthLimit> (when set). |
| controller.command | list | `[]` | Override container command. Empty uses the image entrypoint. |
| controller.extraArgs | list | `[]` | Extra args appended to the chart defaults. Ignored when `args` is set. |
| controller.extraEnvVars | list | `[]` | Extra env vars for the operator container. Supports core/v1.EnvVar including `valueFrom.secretKeyRef` / `configMapKeyRef`. Prefer Secret references over inline values for credentials. |
| controller.extraVolumeMounts | list | `[]` | Extra volume mounts attached to the operator container. |
| controller.extraVolumes | list | `[]` | Extra volumes mounted into the operator pod. |
| controller.image.pullPolicy | string | `"IfNotPresent"` | Operator image pull policy. |
| controller.image.pullSecrets | list | `[]` | Image pull secrets for the operator image. |
| controller.image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod"` | Operator image repository. |
| controller.image.tag | string | `""` | Operator image tag. Defaults to `Chart.AppVersion` when empty. |
| controller.metrics.serviceMonitor.enabled | bool | `false` | Create a Prometheus-Operator ServiceMonitor for the metrics endpoint. Requires prometheus-operator to be installed in the cluster. |
| controller.metrics.serviceMonitor.interval | string | `""` | Scrape interval (e.g. "30s"). Empty uses the Prometheus default. |
| controller.metrics.serviceMonitor.labels | object | `{}` | Additional labels on the ServiceMonitor resource. |
| controller.nodeSelector | object | `{}` | Node selector for operator pod scheduling. |
| controller.podAnnotations | object | `{}` | Annotations applied to operator pods. |
| controller.podLabels | object | `{}` | Additional labels applied to operator pods. |
| controller.replicas | int | `1` | Number of replicas. |
| controller.resources | object | `{}` | Resource requests and limits for the operator container. |
| controller.tolerations | list | `[]` | Tolerations for operator pod scheduling. |
| controller.updateStrategy.type | string | `"RollingUpdate"` | Deployment update strategy type. |
| downloader | object | `{"bandwidthLimit":"","extraEnvVars":[],"extraEnvVarsSecret":"","hf":{"defaultEnvVars":[],"defaultEnvVarsSecret":""},"image":{"pullPolicy":"IfNotPresent","repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod-downloader","tag":""},"maxConcurrentDownloads":3}` | Downloader Job configuration. The operator uses these values when spawning download Jobs for each Artifact. |
| downloader.bandwidthLimit | string | `""` | Per-Job bandwidth limit (e.g. "100Mi", "1Gi"). Empty means unlimited. |
| downloader.extraEnvVars | list | `[]` | Extra env vars injected into EVERY download Job (check, validation, download, cleanup). Follows the bitnami convention: these are applied LAST and OVERRIDE both chart defaults and per-Artifact spec values for the same key. Use this when the admin needs to force a value across all Artifacts regardless of user configuration.  Supports the full core/v1.EnvVar shape — prefer `valueFrom.secretKeyRef` over `value:` for credentials; plain `value:` literals end up in Helm release history and any git-committed values file.  Example (force a cluster-wide telemetry endpoint):   extraEnvVars:     - name: OTEL_EXPORTER_ENDPOINT       value: https://otel.internal |
| downloader.extraEnvVarsSecret | string | `""` | Name of an existing Secret to `envFrom` on every download Job (bitnami convention). Since `envFrom` has lower priority than `env` in Kubernetes, values here act as defaults that any explicit env var (chart-hardcoded, per-Artifact spec, or `extraEnvVars`) can override. When both `extraEnvVarsSecret` and `hf.defaultEnvVarsSecret` are set, `extraEnvVarsSecret` wins for duplicate keys because it is applied AFTER the HF Secret in the Pod's `envFrom` list (K8s merges in order). |
| downloader.hf.defaultEnvVars | list | `[]` | Default HF env vars prepended to every HuggingFace download / validation Job. Supports full core/v1.EnvVar (valueFrom.secretKeyRef etc.). Per-Artifact `spec.source.huggingface.env` and `tokenSecretRef` override matching keys.  Example (private mirror + shared team token):   defaultEnvVars:     - name: HF_ENDPOINT       value: https://hf-mirror.corp.internal     - name: HF_TOKEN       valueFrom:         secretKeyRef:           name: hermod-hf-token           key: HF_TOKEN |
| downloader.hf.defaultEnvVarsSecret | string | `""` | Name of an existing Secret to `envFrom` on every HF download / validation Job. Keys in the Secret are injected as env vars and act as defaults (per-Artifact spec can override matching names). When `extraEnvVarsSecret` is also set, it wins for duplicate keys because it appears later in the Pod's `envFrom` list. |
| downloader.image.pullPolicy | string | `"IfNotPresent"` | Downloader image pull policy. |
| downloader.image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod-downloader"` | Downloader image repository. |
| downloader.image.tag | string | `""` | Downloader image tag. Defaults to `Chart.AppVersion` when empty. |
| downloader.maxConcurrentDownloads | int | `3` | Maximum number of concurrent download Jobs (0 = unlimited). |
| fullnameOverride | string | `""` | Full name override. Defaults to `{Release.Name}-{Chart.Name}`. |
| global | object | `{"imagePullSecrets":[]}` | Global values shared across sub-charts (bitnami/common convention). |
| global.imagePullSecrets | list | `[]` | Image pull secrets shared with sub-charts. |
| nameOverride | string | `""` | Chart name override. Defaults to the chart's `name` field. |
| namespaceOverride | string | `""` | Namespace override. Defaults to `.Release.Namespace`. |
| rbacHelpers | object | `{"enabled":false}` | Install helper ClusterRoles for each CRD (admin/editor/viewer). Bind these to your users/groups to delegate Artifact and ArtifactRepository management. |
| serviceAccount | object | `{"annotations":{},"automount":true,"create":true,"name":""}` | ServiceAccount for the operator. |
| serviceAccount.annotations | object | `{}` | Extra annotations on the ServiceAccount. |
| serviceAccount.automount | bool | `true` | Whether to auto-mount the API credentials for the ServiceAccount. |
| serviceAccount.create | bool | `true` | Whether to create a ServiceAccount. |
| serviceAccount.name | string | `""` | ServiceAccount name. When empty and `create=true`, a name is derived from the chart fullname. |

## Source Code

* <https://github.com/moreh-dev/hermod/tree/main/deploy/helm/hermod>
