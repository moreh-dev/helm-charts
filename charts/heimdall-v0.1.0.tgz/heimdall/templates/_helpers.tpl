{{- define "heimdall.matchLabels" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "heimdall.labels" -}}
{{- range $name, $value := .Values.commonLabels -}}
{{ $name }}: {{ tpl $value $ }}
{{ end -}}
helm.sh/chart: {{ include "common.names.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- end }}
app.kubernetes.io/part-of: mif
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ include "heimdall.matchLabels" . }}
{{- end }}

{{- define "heimdall.namespaceSelectorString" -}}
{{- $pairs := list -}}
{{- range $k := (keys .Values.namespaceSelector.matchLabels | sortAlpha) -}}
{{- $pairs = append $pairs (printf "%s=%s" $k (index $.Values.namespaceSelector.matchLabels $k)) -}}
{{- end -}}
{{- join "," $pairs -}}
{{- end -}}

{{- define "heimdall.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
