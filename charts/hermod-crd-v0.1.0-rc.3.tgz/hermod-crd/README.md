# hermod-crd

Hermod CRDs for LLM artifact lifecycle management

![Version: 0.0.0](https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.0](https://img.shields.io/badge/AppVersion-0.0.0-informational?style=flat-square)

**Homepage:** <https://github.com/moreh-dev/hermod>

## Usage

Install the CRDs before installing the `hermod` operator chart:

```
helm upgrade -i hermod-crd deploy/helm/hermod-crd
```

**CRD lifecycle** — the CustomResourceDefinitions live under `templates/`
(not under Helm's special `crds/` directory) so `helm upgrade` patches
them on schema changes and `helm uninstall` deletes them. Uninstalling
this release **cascade-deletes every Artifact and ArtifactRepository
custom resource** on the cluster, which in turn triggers controller
cleanup of downloaded data. Avoid running `helm uninstall hermod-crd`
in production unless you intend that outcome.

## Source Code

* <https://github.com/moreh-dev/hermod/tree/main/deploy/helm/hermod-crd>
