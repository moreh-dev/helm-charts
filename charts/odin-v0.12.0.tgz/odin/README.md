# odin

![Version: 0.0.0](https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.0](https://img.shields.io/badge/AppVersion-0.0.0-informational?style=flat-square)

Odin; Inference Service operator for MIF

**Homepage:** <https://github.com/moreh-dev/odin>

## Source Code

* <https://github.com/moreh-dev/odin/tree/main/deploy/helm/odin>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | common | 2.31.4 |
| oci://registry.k8s.io/lws/charts | lws | 0.9.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity rules for pods scheduling. |
| args | list | `[]` | Arguments to override the main container's default arguments. |
| command | list | `[]` | Command applied to the main container. If not set, the container's default command is used. |
| commonLabels | object | `{}` | Labels applied to all resources. |
| extraArgs | list | `["--zap-encoder=json","--zap-log-level=info"]` | Extra arguments added to the main container's default arguments. If `args` is set, this value is ignored. |
| fullnameOverride | string | `""` | Full name override. |
| global | object | `{"imagePullSecrets":[]}` | global values are shared across all sub-charts if the value's key matches. |
| global.imagePullSecrets | list | `[]` | Image pull secrets. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| image.pullSecrets | list | `[]` | Image pull secrets. |
| image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/odin"` | Image repository. |
| image.tag | string | `""` | Image tag (defaults to chart appVersion if not set). |
| lws.enabled | bool | `true` | Enable LeaderWorkerSet. If LWS is already deployed, set this to false to use the existing LWS. |
| nameOverride | string | `""` | Chart name override. |
| namespaceOverride | string | `""` | Namespace override. |
| namespaceSelector.matchLabels | object | `{}` | Label selector for namespace filtering (dev use). When set, Odin only watches namespaces with matching labels plus the system namespace. The controller automatically labels the system namespace so webhook validation applies there. Example: { "mif.moreh.io/odin": "<name>" } |
| nodeSelector | object | `{}` | Node selector for pods scheduling. |
| podAnnotations | object | `{}` | Annotations applied to all pods. |
| podLabels | object | `{}` | Labels applied to all pods. |
| presetSync.affinity | object | `{}` | Affinity rules for the sync CronJob pods. |
| presetSync.concurrency | int | `4` | Maximum parallel preset fetches per sync tick. |
| presetSync.enabled | bool | `false` | Enable the preset-sync CronJob that materializes RuntimeBase and ClusterInferenceServiceTemplate objects from an S3 prefix. Off by default; turning it on additionally requires `presetSync.s3.bucket`. Runs as a dedicated CronJob (not embedded in the Odin manager) — see `docs/PRDs/preset-distribution.md` for the design. |
| presetSync.extraArgs | list | `[]` | Extra CLI arguments appended to `odin preset-sync` inside the CronJob container. |
| presetSync.failedJobsHistoryLimit | int | `5` | Number of failed completed Job history entries to retain. |
| presetSync.nodeSelector | object | `{}` | Node selector for the sync CronJob pods. |
| presetSync.resources | object | `{}` | Resource requests and limits for the sync container. |
| presetSync.s3.accessKey | string | `""` | Inline AWS access key ID. When set (with `secretKey`), the chart renders a K8s Secret and wires it into the sync container via `envFrom: secretRef`. Convenient for values-driven deploys on non-EKS clusters; commit-safe alternatives are `existingSecret` (a pre-created Secret) or IRSA (`serviceAccount.annotations`). |
| presetSync.s3.bucket | string | `"moai-inference-preset"` | S3 bucket that hosts preset YAML files. Required when enabled. Default points at the Moreh-managed preset mirror. |
| presetSync.s3.existingSecret | string | `""` | Name of a pre-created K8s Secret carrying `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`. Takes precedence over inline `accessKey` / `secretKey`. Use on non-EKS clusters when the secret is provisioned out of band. Leave empty on EKS clusters that use IRSA. Create with:   kubectl create secret generic <name> -n <ns> \     --from-literal=AWS_ACCESS_KEY_ID=<id> \     --from-literal=AWS_SECRET_ACCESS_KEY=<secret> |
| presetSync.s3.prefix | string | `"prod"` | S3 key prefix under which preset YAMLs are enumerated. Points at the lifecycle the cluster consumes: prod for customer clusters, stage or dev for internal validation. |
| presetSync.s3.region | string | `"ap-northeast-2"` | AWS region for the bucket. When empty the region is resolved from the pod's default credential chain (typically IRSA / node role). |
| presetSync.s3.secretKey | string | `""` | Inline AWS secret access key. Paired with `accessKey`. Prefer `existingSecret` or a SealedSecret / ExternalSecret when values files live in git. |
| presetSync.schedule | string | `"*/5 * * * *"` | Cron schedule for the sync. Default: every 5 minutes. |
| presetSync.serviceAccount.annotations | object | `{}` | Annotations added to the preset-sync ServiceAccount. On EKS this is where the `eks.amazonaws.com/role-arn` IRSA annotation goes so the CronJob can talk to S3 without static credentials. Mutually exclusive with `s3.accessKey` / `s3.secretKey` / `s3.existingSecret` — pick one authentication path. |
| presetSync.startingDeadlineSeconds | int | `200` | Deadline in seconds for starting a Job if it misses its scheduled time. Missed schedules older than this are counted as failed. Null means no deadline. |
| presetSync.successfulJobsHistoryLimit | int | `3` | Number of successful completed Job history entries to retain. |
| presetSync.tolerations | list | `[]` | Tolerations for the sync CronJob pods. |
| presetSync.ttlSecondsAfterFinished | int | `3600` | TTL applied to each Job's Pod after it finishes. Null keeps Pods until `failedJobsHistoryLimit` prunes them. |
| replicas | int | `1` | Number of replicas. |
| resources | object | `{}` | Resource requests and limits for the main container. |
| revisionHistoryLimit | int | `3` | Number of old ReplicaSets to retain for rollback history. |
| serviceAccount.annotations | object | `{}` | Annotations added to the ServiceAccount. |
| serviceAccount.automount | bool | `true` | Whether to automatically mount API credentials. |
| serviceAccount.create | bool | `true` | Whether to create a ServiceAccount. |
| serviceAccount.name | string | `""` | Name of the ServiceAccount (auto-generated if empty and create is true). |
| tolerations | list | `[]` | Tolerations for pods scheduling. |
| updateStrategy.type | string | `"RollingUpdate"` | Update strategy for deployment. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
