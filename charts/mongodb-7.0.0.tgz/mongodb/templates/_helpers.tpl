{{/*
Expand the name of the chart.
*/}}
{{- define "mongodb.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name (≤63 chars).
*/}}
{{- define "mongodb.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart label.
*/}}
{{- define "mongodb.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "mongodb.labels" -}}
helm.sh/chart: {{ include "mongodb.chart" . }}
{{ include "mongodb.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "mongodb.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mongodb.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Container image string.
*/}}
{{- define "mongodb.image" -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.image.repository .Values.image.tag -}}
{{- end -}}

{{/*
Headless service name (StatefulSet's serviceName).
*/}}
{{- define "mongodb.headlessServiceName" -}}
{{- printf "%s-headless" (include "mongodb.fullname" .) -}}
{{- end -}}

{{/*
Root password secret: existing if specified, otherwise the default
generated one. The default generated secret is named "<fullname>-rootpw".
*/}}
{{- define "mongodb.rootpwSecretName" -}}
{{- if .Values.auth.existingSecret -}}
{{- .Values.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-rootpw" (include "mongodb.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
KeyFile secret name: existing if specified, else the default generated.
*/}}
{{- define "mongodb.keyFileSecretName" -}}
{{- if .Values.auth.existingKeyFileSecret -}}
{{- .Values.auth.existingKeyFileSecret -}}
{{- else -}}
{{- printf "%s-keyfile" (include "mongodb.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Entrypoint ConfigMap name (carries the bootstrap wrapper script).
*/}}
{{- define "mongodb.entrypointConfigMapName" -}}
{{- printf "%s-entrypoint" (include "mongodb.fullname" .) -}}
{{- end -}}
