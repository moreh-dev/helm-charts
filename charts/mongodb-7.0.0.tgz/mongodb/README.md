# mongodb

MongoDB ReplicaSet preconfigured for the Heimdall Responses API tiered
store (MAF-19708). Self-contained StatefulSet using Docker Hub Official
library/mongo image. The chart auto-bootstraps the ReplicaSet
(rs.initiate + root user creation) on first install via a wrapper-script
entrypoint on pod-0; the bootstrap is idempotent on restart and can be
disabled with `bootstrap.enabled=false` for fully manual control.

## What this chart deploys

- 3-replica StatefulSet running `mongod --replSet=rs0 --auth --keyFile`
  (pod management: `Parallel`, so all members come up together — required
  for the `rs.initiate` quorum check)
- Headless `Service` for stable per-pod DNS (member hostnames)
- ClusterIP `Service` as the client entry point
- `prepare-keyfile` initContainer that copies the keyFile into a
  pod-local tmpfs at mode 0400 (works around `fsGroup` opening the
  permissions on the Secret-mounted file)
- `<release>-mongodb-entrypoint` ConfigMap holding the wrapper script
  that runs `mongod` and, on pod-0 only, runs the idempotent
  `rs.initiate()` + root-user creation
- Two Secrets (auto-generated unless overridden):
  - `<release>-keyfile` — internal-auth keyFile shared across replicas
  - `<release>-rootpw`  — root user credentials

## Bootstrap

When `bootstrap.enabled` is `true` (default), the wrapper-script
entrypoint on pod-0:

1. Starts `mongod` in the background and forwards SIGTERM/SIGINT.
2. Waits for every member's mongod to answer `db.adminCommand('ping')`.
3. Idempotency gate: if `rs.status().ok` already returns `1` under the
   existing root credentials, skips the rest.
4. Otherwise runs `rs.initiate()`, waits for primary election, then
   `db.getSiblingDB('admin').createUser(...)`.
5. Blocks on the foreground mongod until shutdown.

This matches the wrapper-script entrypoint pattern used by
`bitnami/mongodb` and `helm/stable mongodb-replicaset`. K8s discourages
running setup-critical work in `lifecycle.postStart`, which is why this
chart does the bootstrap inside the main process tree instead.

Set `bootstrap.enabled: false` to ship just the StatefulSet + Services
+ Secrets and run `rs.initiate()` / `createUser()` by hand
(`NOTES.txt` has the commands).

## Prerequisites

- Kubernetes ≥ 1.27
- A `StorageClass` named `ceph-block` (or override `persistence.storageClassName`)
- `mongosh` is bundled in `library/mongo:7.0`; no client install required

## Install

```bash
cd deploy/helm
helm install heimdall-mongo ./mongodb -n mif
```

After all pods are Ready, verify:

```bash
NS=mif
RELEASE=heimdall-mongo
ROOTPW=$(kubectl get secret -n $NS $RELEASE-mongodb-rootpw -o jsonpath='{.data.password}' | base64 -d)
kubectl exec -n $NS $RELEASE-mongodb-0 -- mongosh \
  -u root -p "$ROOTPW" --authenticationDatabase admin --quiet \
  --eval 'rs.status().members.map(m => m.name + ":" + m.stateStr).join(" | ")'
# → ...:PRIMARY | ...:SECONDARY | ...:SECONDARY
```

Bootstrap progress lives in pod-0's logs:

```bash
kubectl logs -n $NS $RELEASE-mongodb-0 -c mongod | grep '\[entrypoint\]'
```

## Connection URI

```
mongodb://root:<password>@<release>-mongodb.<namespace>.svc.cluster.local:27017/?replicaSet=rs0&authSource=admin
```

The driver discovers the other members through the seed host's
`isMaster` response.

## Image

| Component | Image |
|-----------|-------|
| MongoDB server | `docker.io/library/mongo:7.0` (Docker Hub Official) |

No Bitnami images. Upgrade to `mongo:8.0`:

```bash
helm upgrade heimdall-mongo ./mongodb -n mif --set image.tag=8.0
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| auth | object | `{"enabled":true,"existingKeyFileSecret":"","existingSecret":"","rootUser":"root"}` | Auth configuration. Mandatory once the replicaset is initialized — `--auth` is always set on mongod. The chart auto-generates a random root password and keyFile if external Secrets are not provided. |
| auth.enabled | bool | `true` | Enable mongod `--auth` (always true; included for documentation). |
| auth.existingKeyFileSecret | string | `""` | Externally-managed Secret with key `keyfile` (6–1024 chars). If empty, the chart generates a 768-char random keyFile (preserved across upgrades via lookup). |
| auth.existingSecret | string | `""` | Externally-managed Secret with key `password` (and optional `username`). If empty, the chart generates a 24-char random password (preserved across upgrades via lookup). |
| auth.rootUser | string | `"root"` | Root username for the generated/admin user. |
| bootstrap | object | `{"enabled":true,"mongodReadyTimeoutSeconds":300,"primaryElectionTimeoutSeconds":60}` | ReplicaSet bootstrap. When `enabled: true` (default), pod-0's mongod container runs a `lifecycle.postStart` hook that idempotently performs `rs.initiate()` and creates the root user — no extra image, no RBAC, no Helm hooks. Disable to drive the bootstrap manually (NOTES.txt has the commands). |
| bootstrap.enabled | bool | `true` | Run the postStart bootstrap on pod-0. Set to false for fully manual control. |
| bootstrap.mongodReadyTimeoutSeconds | int | `300` | How long postStart waits for mongod to accept connections before failing (seconds). Covers slow image pulls / scheduling. |
| bootstrap.primaryElectionTimeoutSeconds | int | `60` | How long postStart waits for primary election after `rs.initiate` before failing (seconds). |
| fullnameOverride | string | `""` | Full name override. |
| image | object | `{"pullPolicy":"IfNotPresent","registry":"docker.io","repository":"library/mongo","tag":"7.0"}` | Container image. Default `docker.io/library/mongo:7.0` (Docker Hub Official). Override `tag` to `"8.0"` to upgrade. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| image.registry | string | `"docker.io"` | Image registry. |
| image.repository | string | `"library/mongo"` | Image repository. |
| image.tag | string | `"7.0"` | Image tag. |
| nameOverride | string | `""` | Chart name override. |
| persistence | object | `{"size":"50Gi","storageClassName":"ceph-block"}` | PVC configuration (per pod). Stores mongod data dir (collections, indexes, oplog, system.replset). |
| persistence.size | string | `"50Gi"` | PVC size per pod. |
| persistence.storageClassName | string | `"ceph-block"` | StorageClass for PVCs. |
| replicaSet | object | `{"name":"rs0","replicas":3,"resources":{"limits":{"memory":"4Gi"},"requests":{"cpu":"250m","memory":"1Gi"}}}` | ReplicaSet topology configuration. |
| replicaSet.name | string | `"rs0"` | ReplicaSet name (used in `rs.initiate()`, mongod `--replSet` flag, and client connection string `?replicaSet=...`). |
| replicaSet.replicas | int | `3` | Number of mongod replicas (== ReplicaSet members). |
| replicaSet.resources | object | `{"limits":{"memory":"4Gi"},"requests":{"cpu":"250m","memory":"1Gi"}}` | Mongod container resource requests/limits. |
| service | object | `{"port":27017}` | Service configuration. |
| service.port | int | `27017` | Mongod port (used on both headless and ClusterIP Services). |

## Migration from 0.1.x (Bitnami wrapper)

Version `0.1.x` was a thin wrapper around `bitnami/mongodb` using
`bitnamilegacy/mongodb`. Version `0.2.0` switched to a self-contained
StatefulSet on Docker Hub Official `mongo:7.0` but required the admin
to run `rs.initiate()` manually. Version `0.3.0` adds the
wrapper-script entrypoint that bootstraps the ReplicaSet on first
install.

This is a **breaking change** from `0.1.x`. Map keys as follows:

| 0.1.x key | 0.3.0 key |
|-----------|-----------|
| `mongodb.image.repository` | `image.repository` |
| `mongodb.image.tag` | `image.tag` |
| `mongodb.architecture: replicaset` | (removed; always replicaset) |
| `mongodb.replicaCount` | `replicaSet.replicas` |
| `mongodb.persistence.size` | `persistence.size` |
| `mongodb.persistence.storageClassName` | `persistence.storageClassName` |
| `mongodb.auth.enabled` | `auth.enabled` |
| `mongodb.global.security.allowInsecureImages` | (removed) |

Upgrading from `0.2.0`: `helm upgrade` is sufficient — the wrapper
script's idempotency gate detects the already-bootstrapped cluster and
becomes a no-op once mongod restarts under the new pod template.

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
