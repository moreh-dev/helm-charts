{{- define "portal.api3.fullname" -}}
{{ include "portal.fullname" . | trunc 55 | trimSuffix "-" }}-api3
{{- end }}

{{- define "portal.api3.matchLabels" -}}
app.kubernetes.io/name: {{ include "portal.api3.fullname" . }}
app: {{ include "portal.api3.fullname" . }}
{{- end }}

{{- define "portal.api3.labels" -}}
{{ include "portal.labels" . }}
{{ include "portal.api3.matchLabels" . }}
{{- end }}
