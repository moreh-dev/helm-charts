
{{- define "portal.web.fullname" -}}
{{ include "portal.fullname" . | trunc 55 | trimSuffix "-" }}-web
{{- end }}

{{- define "portal.web.matchLabels" -}}
app.kubernetes.io/name: {{ include "portal.web.fullname" . }}
app: {{ include "portal.web.fullname" . }}
{{- end }}

{{- define "portal.web.labels" -}}
{{ include "portal.labels" . }}
{{ include "portal.web.matchLabels" . }}
{{- end }}
