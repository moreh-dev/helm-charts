{{/*
Full image reference, e.g. ghcr.io/org/tt-dra-plugin:sha-abc1234.
Tag defaults to the (CI-stamped) chart appVersion when image.tag is empty.
*/}}
{{- define "tt-dra-plugin.image" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{ .Values.image.repository }}:{{ $tag }}
{{- end }}

{{/*
Merged image pull secrets (chart-local + umbrella global). Renders the full
`imagePullSecrets:` block, or nothing when both are empty.
*/}}
{{- define "tt-dra-plugin.imagePullSecrets" -}}
{{- $secrets := concat (.Values.imagePullSecrets | default list) ((.Values.global).imagePullSecrets | default list) -}}
{{- if $secrets }}
imagePullSecrets:
{{- range $secrets }}
- {{ toYaml . | nindent 2 | trim }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels applied to every resource.
*/}}
{{- define "tt-dra-plugin.labels" -}}
app.kubernetes.io/name: tt-dra-plugin
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
{{- end }}
