# tt-dra-plugin Helm Chart

Packages the Wormhole DRA plugin and node labeler as a single deployable unit.

## Prerequisites (standalone install — no tt-mif umbrella needed)

- **NFD PCI label** — the plugin DaemonSet's default `nodeSelector` gates on
  `feature.node.kubernetes.io/pci-1200_1e52.present: "true"`. Either the cluster
  already runs node-feature-discovery, or enable the bundled optional subchart
  (`--set nfd.enabled=true`), or override `nodeSelector` with your own TT-node
  marker. Under the tt-mif umbrella keep `nfd.enabled=false` — the umbrella
  ships its own NFD sibling.
- **DRA enabled** on the cluster (Kubernetes ≥ 1.32 with `resource.k8s.io/v1`,
  CDI configured in containerd).

The interfaces other components rely on (driver name, DeviceClass, device
attributes, node labels) are documented in [`../../docs/CONTRACT.md`](../../docs/CONTRACT.md).

---

## What the chart manages

| Resource | Kind | Namespace |
|---|---|---|
| `tt-dra-plugin` | ServiceAccount | kube-system |
| `tt-dra-plugin` | ClusterRole | — |
| `tt-dra-plugin` | ClusterRoleBinding | — |
| `tenstorrent.com` | DeviceClass | — |
| `tt-dra-kubelet-plugin` | DaemonSet | kube-system |

The DaemonSet uses the chart's `tt-dra-plugin` ServiceAccount. The plugin self-detects
arch/model/chip-count from `/dev/tenstorrent` and publishes them as ResourceSlice
attributes — it neither reads nor writes node labels (tt-node-detector is retired).

---

## Normal usage — install a released version

Releases are tag-driven (SRE Helm Chart Release Guide): a `vX.Y.Z` tag publishes the
image to the internal ECR and this chart to artifact-keeper + `moreh-dev/helm-charts`;
a `vX.Y.Z-rc.N` tag publishes to artifact-keeper only.

```bash
helm repo add moreh https://moreh-dev.github.io/helm-charts
helm upgrade --install tt-dra-plugin moreh/tt-dra-plugin -n kube-system --version vX.Y.Z
```

---

## Manual Helm commands (troubleshooting / first install)

### Install from scratch

```bash
cd /home/ubuntu/tt-dra-plugin

helm upgrade --install tt-dra-plugin ./helm/tt-dra-plugin \
  --namespace kube-system
```

### Upgrade to a specific image SHA

```bash
helm upgrade tt-dra-plugin ./helm/tt-dra-plugin \
  --namespace kube-system \
  --set image.tag=sha-abc1234
```

### Check release status

```bash
helm list -n kube-system
helm status tt-dra-plugin -n kube-system
```

### View deploy history

```bash
helm history tt-dra-plugin -n kube-system
```

### Rollback to the previous release

```bash
helm rollback tt-dra-plugin -n kube-system
# or to a specific revision:
helm rollback tt-dra-plugin 2 -n kube-system
```

### Uninstall

```bash
helm uninstall tt-dra-plugin -n kube-system
```

---

## Values reference

| Key | Default | Description |
|---|---|---|
| `image.repository` | internal ECR `…/tt-dra-plugin` | Image repo. Air-gapped clusters override with the in-cluster registry. |
| `image.tag` | `""` (= chart appVersion) | Image tag; the release pipeline stamps appVersion to the tag being released. |
| `image.pullPolicy` | `IfNotPresent` | ECR tags are immutable, so no need to re-pull. |
| `imagePullSecrets` | `[]` | Set only if pulling from a private registry. |
| `plugin.healthCheckInterval` | `30s` | How often to check chip accessibility via `os.Open(/dev/tenstorrent/N)`. Set to `0` to disable. |
| `plugin.ttSmiPath` | `/usr/local/bin/tt-smi` | Path to `tt-smi` binary (used by node-labeler only). |
| `plugin.metricsPort` | `9090` | Prometheus metrics port inside the plugin container. |
| `plugin.cdiDir` | `/var/run/cdi` | Directory where CDI spec files are written. |
| `plugin.checkpointDir` | `/var/lib/wh-dra/checkpoint` | Crash-recovery checkpoint location. |
| `plugin.pluginDir` | `/var/lib/kubelet/plugins/tenstorrent.com` | kubelet plugin socket directory. |
| `plugin.registrarDir` | `/var/lib/kubelet/plugins_registry` | kubelet plugin registration directory. |
| `nodeSelector` | NFD PCI label | The DRA plugin DaemonSet runs only on nodes with this label (hardware presence). |

The plugin self-detects `arch` (from `/dev/tenstorrent/by-id/`), `chip-count`, and `model`
(device type via `(arch, chip-count)`: n150/n300/t3k/galaxy) — no `tt-smi`, no topology ConfigMap —
and publishes them as ResourceSlice attributes.
Mesh placement/rank is owned by `tt-topology-scheduler` (FM + `tt.moreh.io/mesh-rank`), not labels.

---

## Customising values without editing values.yaml

Pass `--set` flags on the command line or create a `values-override.yaml` file:

```yaml
# values-override.yaml — not committed, used for local overrides
plugin:
  healthCheckInterval: 60s
```

```bash
helm upgrade tt-dra-plugin ./helm/tt-dra-plugin \
  --namespace kube-system \
  -f values-override.yaml
```

---

## Disabling the health check

The health check calls `os.Open(/dev/tenstorrent/N)` every 30 s. If the T3K hardware is
being serviced or the driver needs reloading, you can disable it temporarily without
redeploying the image:

```bash
helm upgrade tt-dra-plugin ./helm/tt-dra-plugin \
  --namespace kube-system \
  --set plugin.healthCheckInterval=0
```

Re-enable after the hardware is stable:

```bash
helm upgrade tt-dra-plugin ./helm/tt-dra-plugin \
  --namespace kube-system \
  --set plugin.healthCheckInterval=30s
```

---

## Chart structure

```
helm/tt-dra-plugin/
  Chart.yaml               chart metadata (name, version, appVersion)
  values.yaml              default values — source of truth for configuration
  templates/
    _helpers.tpl           shared template helpers (image ref, common labels)
    rbac.yaml              ServiceAccount + ClusterRole + ClusterRoleBinding
    deviceclass.yaml       DeviceClass (tenstorrent.com)
    daemonset.yaml         tt-dra-kubelet-plugin DaemonSet
```
