# hermod

![Version: 0.0.3](https://img.shields.io/badge/Version-0.0.3-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.3](https://img.shields.io/badge/AppVersion-0.0.3-informational?style=flat-square)

Hermod - LLM artifact lifecycle operator for Kubernetes

**Homepage:** <https://github.com/moreh-dev/hermod>

## Source Code

* <https://github.com/moreh-dev/hermod>

> [!CAUTION]
> Prerequisite: `cert-manager` must be installed before you begin.

## Requirements

Kubernetes: `>= 1.32.0-0`

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| certManager | object | `{"enable":true}` | Cert-manager integration for TLS certificates. Required for webhook and metrics endpoint certificates. |
| certManager.enable | bool | `true` | Enable cert-manager certificate provisioning. |
| controller | object | `{"downloadBandwidthLimit":"","downloaderImage":{"repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod-downloader","tag":""},"huggingface":{"defaultEnv":{}},"maxConcurrentDownloads":3}` | Controller-specific configuration. |
| controller.downloadBandwidthLimit | string | `""` | Download bandwidth limit per Job (e.g., "100Mi", "1Gi"). Empty string means unlimited. |
| controller.downloaderImage.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod-downloader"` | Downloader image repository. |
| controller.downloaderImage.tag | string | `""` | Image tag (defaults to chart appVersion if not set). |
| controller.huggingface | object | `{"defaultEnv":{}}` | Default HuggingFace environment variables for download and validation Jobs. Per-Artifact env values (`spec.source.huggingface.env`) override these. |
| controller.huggingface.defaultEnv | object | `{}` | Default environment variables applied to all HuggingFace download Jobs. |
| controller.maxConcurrentDownloads | int | `3` | Maximum number of concurrent artifact downloads (0 = unlimited). |
| crd | object | `{"enable":true,"keep":true}` | Custom Resource Definitions. |
| crd.enable | bool | `true` | Install CRDs with the chart. |
| crd.keep | bool | `true` | Keep CRDs when uninstalling. |
| manager | object | `{"affinity":{},"args":["--leader-elect"],"env":[],"envOverrides":{},"image":{"pullPolicy":"IfNotPresent","repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod","tag":""},"imagePullSecrets":[],"nodeSelector":{},"podSecurityContext":{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}},"replicas":1,"resources":{"limits":{"cpu":"500m","memory":"128Mi"},"requests":{"cpu":"10m","memory":"64Mi"}},"securityContext":{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true},"tolerations":[]}` | Controller manager deployment configuration. |
| manager.affinity | object | `{}` | Pod affinity rules. |
| manager.args | list | `["--leader-elect"]` | Arguments passed to the manager binary. |
| manager.env | list | `[]` | Environment variables for the manager container. |
| manager.envOverrides | object | `{}` | Environment variable overrides (`--set manager.envOverrides.VAR=value`). Same name in `env` above: this value takes precedence. |
| manager.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| manager.image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod"` | Image repository. |
| manager.image.tag | string | `""` | Image tag (defaults to chart appVersion if not set). |
| manager.imagePullSecrets | list | `[]` | Image pull secrets. |
| manager.nodeSelector | object | `{}` | Pod node selector. |
| manager.podSecurityContext | object | `{"runAsNonRoot":true,"seccompProfile":{"type":"RuntimeDefault"}}` | Pod-level security context. |
| manager.replicas | int | `1` | Number of replicas. |
| manager.resources | object | `{"limits":{"cpu":"500m","memory":"128Mi"},"requests":{"cpu":"10m","memory":"64Mi"}}` | Resource limits and requests. |
| manager.securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true}` | Container-level security context. |
| manager.tolerations | list | `[]` | Pod tolerations. |
| metrics | object | `{"enable":true,"port":8443}` | Controller metrics endpoint. Exposes /metrics with RBAC protection. |
| metrics.enable | bool | `true` | Enable metrics endpoint. |
| metrics.port | int | `8443` | Metrics server port. |
| rbacHelpers | object | `{"enable":false}` | Helper RBAC roles for managing custom resources. |
| rbacHelpers.enable | bool | `false` | Install convenience admin/editor/viewer roles for CRDs. |
| serviceMonitor | object | `{"enable":false}` | Prometheus ServiceMonitor for metrics scraping. Requires prometheus-operator to be installed in the cluster. |
| serviceMonitor.enable | bool | `false` | Enable ServiceMonitor creation. |
| webhook | object | `{"caBundle":"","certSecret":"","enable":true,"port":9443}` | Webhook server configuration. |
| webhook.caBundle | string | `""` | Base64-encoded CA bundle for webhook TLS verification. Only used when `certManager.enable` is false. |
| webhook.certSecret | string | `""` | Name of an existing TLS Secret for webhook serving certificates. Only used when `certManager.enable` is false and `webhook.enable` is true. The Secret must contain `tls.crt` and `tls.key` entries. |
| webhook.enable | bool | `true` | Enable admission webhooks. |
| webhook.port | int | `9443` | Webhook server port. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
