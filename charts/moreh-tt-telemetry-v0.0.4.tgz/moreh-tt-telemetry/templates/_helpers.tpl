{{/*
Chart name. Honors this chart's `.Values.name` override (the same key
every resource template uses for naming + the legacy `app:` label),
falling back to .Chart.Name. Trunc to 63 chars for k8s label limits.
*/}}
{{- define "tt-telemetry.name" -}}
{{- default .Chart.Name .Values.name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Chart name + version, for the helm.sh/chart label.
*/}}
{{- define "tt-telemetry.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common Kubernetes Recommended Labels. Applied to metadata.labels on every
resource and to spec.template.metadata.labels on Deployments/DaemonSets.

NOTE: do NOT use this for spec.selector.matchLabels — the existing selector
(`app: tt-telemetry` / `app: tt-telemetry-aggregator`) is immutable on
already-installed resources, so it stays as-is for backwards compatibility.
*/}}
{{- define "tt-telemetry.labels" -}}
helm.sh/chart: {{ include "tt-telemetry.chart" . }}
app.kubernetes.io/name: {{ include "tt-telemetry.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: tt-operator
{{- end }}
