# moreh-tt-telemetry Helm chart

Collector DaemonSet (one pod per Tenstorrent node, metrics on the pod's
`:18080/metrics`) built from `moreh/main`. The aggregator Deployment and its
Ingress are off by default; Prometheus scrapes the collector pods directly.

## Standalone install (no tt-mif)

```bash
# Image: built from moreh/main and pushed to the in-cluster registry. The registry
# serves plain HTTP, so push through localhost on the host that runs it.
scripts/build_local_docker.sh 0.0.4          # -> 192.168.6.211:5000/moreh-tt-telemetry:0.0.4
docker tag 192.168.6.211:5000/moreh-tt-telemetry:0.0.4 localhost:5000/moreh-tt-telemetry:0.0.4
docker push localhost:5000/moreh-tt-telemetry:0.0.4

helm install tt-telemetry ./helm -n tt-telemetry --create-namespace \
  -f helm/values-standalone.yaml
kubectl -n tt-telemetry get pods -o wide     # one collector per TT node
curl -s http://<collector-pod-ip>:18080/metrics | grep -c '^tt_'
```

`helm/values-standalone.yaml` is the documented minimal values file. It points
the image at the MO in-cluster registry, because MO has no ECR pull
credentials, and otherwise keeps the chart defaults (aggregator off, toleration
for the `tenstorrent.com/npu:NoSchedule` taint, root + privileged collector).
Enable `podMonitor` / `grafanaDashboard` on clusters that run
prometheus-operator / a Grafana sidecar.

By default the chart pulls the image the release CI pushes to the internal ECR,
tagged like the chart itself.

The chart defaults to `config.collection_interval: 2`, which the Moreh Tensix
utilization metrics need; keep it at 2 s.

The collector must run as uid 0: on nodes protected by `moreh-lock`, the device
gate admits root outside a reservation and rejects every other uid.

With `config.enable_subprocess: true` (the default) the server stops the
collector when a device reset is announced (tt-smi, moreh-smi >= 0.2.1) and
starts a fresh one when the reset is over, so no device stays open during the
reset. The notifications arrive through the `/tmp/tt_umd_listeners` hostPath
the chart mounts; `tt_reset_count` counts them.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| aggregateSources | list | `[]` | Hosts the aggregator polls; rendered into the binary's `--aggregate-from` flag. Only used when aggregator.enabled is true. |
| aggregator | object | `{"enabled":false,"readinessProbe":{"failureThreshold":3,"httpGet":{"path":"/api/status","port":"telemetry-http"},"initialDelaySeconds":5,"periodSeconds":10,"timeoutSeconds":3}}` | Aggregator Deployment that polls aggregateSources and serves merged telemetry. |
| aggregator.enabled | bool | `false` | Deploy the aggregator Deployment; false ships only the collector DaemonSet. |
| aggregator.readinessProbe | object | `{"failureThreshold":3,"httpGet":{"path":"/api/status","port":"telemetry-http"},"initialDelaySeconds":5,"periodSeconds":10,"timeoutSeconds":3}` | Readiness probe applied to aggregator pods; set null to disable. |
| config | object | `{"collection_interval":2,"enable_subprocess":true}` | Map rendered as the tt-telemetry binary's `--config` file (ConfigMap-mounted). |
| daemonset | object | `{"affinity":{"nodeAffinity":{"requiredDuringSchedulingIgnoredDuringExecution":{"nodeSelectorTerms":[{"matchExpressions":[{"key":"tenstorrent.com/has-tt","operator":"In","values":["true"]},{"key":"tenstorrent.com/deploy.tt-telemetry","operator":"NotIn","values":["false"]}]},{"matchExpressions":[{"key":"feature.node.kubernetes.io/pci-1200_1e52.present","operator":"In","values":["true"]},{"key":"tenstorrent.com/deploy.tt-telemetry","operator":"NotIn","values":["false"]}]}]}}},"hostPID":true,"nodeSelector":[],"tolerations":[{"effect":"NoSchedule","key":"tenstorrent.com/npu","operator":"Exists"}],"updateStrategy":{"rollingUpdate":{"maxUnavailable":"25%"},"type":"RollingUpdate"}}` | Collector DaemonSet scheduling and update settings. |
| daemonset.affinity | object | `{"nodeAffinity":{"requiredDuringSchedulingIgnoredDuringExecution":{"nodeSelectorTerms":[{"matchExpressions":[{"key":"tenstorrent.com/has-tt","operator":"In","values":["true"]},{"key":"tenstorrent.com/deploy.tt-telemetry","operator":"NotIn","values":["false"]}]},{"matchExpressions":[{"key":"feature.node.kubernetes.io/pci-1200_1e52.present","operator":"In","values":["true"]},{"key":"tenstorrent.com/deploy.tt-telemetry","operator":"NotIn","values":["false"]}]}]}}}` | Affinity applied to the collector DaemonSet; default ORs has-tt and NFD PCI labels. |
| daemonset.hostPID | bool | `true` | Share the node's PID namespace; required for tt_process_count and tt_process. |
| daemonset.nodeSelector | list | `[]` | Legacy hostname allow-list; when set, overrides daemonset.affinity. |
| daemonset.tolerations | list | `[{"effect":"NoSchedule","key":"tenstorrent.com/npu","operator":"Exists"}]` | Tolerations applied to the collector DaemonSet; default tolerates the tenstorrent.com/npu taint. |
| daemonset.updateStrategy | object | `{"rollingUpdate":{"maxUnavailable":"25%"},"type":"RollingUpdate"}` | Collector DaemonSet update strategy. |
| deployment | object | `{"affinity":{},"nodeSelectorMatchExpressions":[{"key":"tenstorrent.com/app-node","operator":"In","values":["true"]}],"preferredSchedulingTerms":[{"preference":{"matchExpressions":[{"key":"feature.node.kubernetes.io/pci-1200_1e52.present","operator":"DoesNotExist"}]},"weight":100}]}` | Aggregator Deployment scheduling settings. |
| deployment.affinity | object | `{}` | Affinity applied verbatim to the aggregator Deployment; overrides the composed default. |
| deployment.nodeSelectorMatchExpressions | list | `[{"key":"tenstorrent.com/app-node","operator":"In","values":["true"]}]` | nodeSelectorTerms matchExpressions applied to the aggregator Deployment. |
| deployment.preferredSchedulingTerms | list | `[{"preference":{"matchExpressions":[{"key":"feature.node.kubernetes.io/pci-1200_1e52.present","operator":"DoesNotExist"}]},"weight":100}]` | preferredDuringSchedulingIgnoredDuringExecution terms for the aggregator Deployment. |
| grafanaDashboard | object | `{"annotations":{},"enabled":false,"labels":{"grafana_dashboard":"1"},"namespace":""}` | Grafana dashboard ConfigMap for the tt-telemetry device overview. |
| grafanaDashboard.annotations | object | `{}` | Annotations on the ConfigMap; common use is a Grafana sidecar folder hint. |
| grafanaDashboard.enabled | bool | `false` | Create the dashboard ConfigMap. |
| grafanaDashboard.labels | object | `{"grafana_dashboard":"1"}` | Labels added to the ConfigMap; default matches the Grafana sidecar's canonical discovery label. |
| grafanaDashboard.namespace | string | `""` | Namespace the ConfigMap is created in. Defaults to release namespace. |
| hostConfigOverrideDir | string | `""` | Host path mounted read-write into containers and exported as TT_TELEMETRY_HOST_CONFIG_OVERRIDE_DIR. |
| image | object | `{"pullPolicy":"","repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/moreh-tt-telemetry","tag":""}` | Container image for the aggregator Deployment and the collector DaemonSet. |
| image.pullPolicy | string | `""` | Container imagePullPolicy for the aggregator Deployment and collector DaemonSet. Empty (default) omits the field, so Kubernetes applies its native default (Always for :latest, IfNotPresent otherwise). Set Always to re-pull a moving tag on every pod start. |
| image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/moreh-tt-telemetry"` | Image repository: the internal ECR, where the release CI pushes on tag. Clusters that cannot pull from it set their own registry. |
| image.tag | string | `""` | Image tag. Empty (default) uses the chart's appVersion; the release CI sets it to the git tag, so a released chart runs the image built from that tag. |
| imagePullSecrets | list | `[]` | Pull secrets attached to aggregator + collector pod specs. |
| livenessProbe | object | `{"failureThreshold":3,"httpGet":{"path":"/api/status","port":"telemetry-http"},"initialDelaySeconds":15,"periodSeconds":30,"timeoutSeconds":5}` | Liveness probe applied to aggregator + collector pods; set null to disable. |
| name | string | `"tt-telemetry"` | Release name override; baseline label/selector value used by templates. |
| namespace | string | `""` | Namespace override for chart-rendered resources; empty installs into the release namespace. |
| network | object | `{"aggregatorUrl":"","ingressClassName":"nginx","nodePort":30080,"servicePort":18080,"telemetryHttpPort":18080,"tls":{"clusterIssuer":"","secretName":""}}` | Network configuration for the aggregator (ports, ingress, TLS). |
| network.aggregatorUrl | string | `""` | FQDN set on the aggregator Service ingress; empty by default. |
| network.ingressClassName | string | `"nginx"` | IngressClass name for the aggregator ingress. |
| network.nodePort | int | `30080` | NodePort exposed on every node for the aggregator Service. |
| network.servicePort | int | `18080` | Port the aggregator Service exposes inside the cluster. |
| network.telemetryHttpPort | int | `18080` | Port the tt-telemetry container listens on for HTTP/metrics. |
| network.tls | object | `{"clusterIssuer":"","secretName":""}` | TLS settings for the aggregator ingress; empty secretName serves plain HTTP. |
| network.tls.clusterIssuer | string | `""` | cert-manager ClusterIssuer that should provision the TLS cert. |
| network.tls.secretName | string | `""` | Kubernetes Secret holding the TLS cert/key for aggregatorUrl. |
| podMonitor | object | `{"enabled":false,"labels":{"release":"prometheus"},"namespace":"monitoring"}` | prometheus-operator PodMonitor for the collector DaemonSet. |
| podMonitor.enabled | bool | `false` | Create the PodMonitor object. |
| podMonitor.labels | object | `{"release":"prometheus"}` | Labels added to PodMonitor metadata; must match prometheus-operator's podMonitorSelector. |
| podMonitor.namespace | string | `"monitoring"` | Namespace the PodMonitor is created in; must be watched by prometheus-operator. |
| readinessProbe | object | `{"failureThreshold":3,"httpGet":{"path":"/metrics","port":"telemetry-http"},"initialDelaySeconds":5,"periodSeconds":10,"timeoutSeconds":3}` | Readiness probe applied to collector pods; set null to disable. |
| resources | object | `{"limits":{"cpu":"500m","memory":"2Gi"},"requests":{"cpu":"100m","memory":"1Gi"}}` | CPU/memory requests and limits applied to aggregator and collector pods. |
