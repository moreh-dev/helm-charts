# heimdall-inference-scheduler

![Version: 0.0.0](https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.0](https://img.shields.io/badge/AppVersion-0.0.0-informational?style=flat-square)

Inference scheduler

**Homepage:** <https://github.com/moreh-dev/heimdall-inference-scheduler>

## Source Code

* <https://github.com/moreh-dev/heimdall-inference-scheduler>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | common | 2.31.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity rules for pods scheduling. |
| args | list | `[]` | Arguments to override the main container's default arguments. |
| command | list | `[]` | Command applied to the main container. If not set, the container's default command is used. |
| commonLabels | object | `{}` | Labels applied to all resources. |
| config | object | `{"apiVersion":"llm-d.ai/v1alpha1","featureGates":[],"kind":"EndpointPickerConfig","plugins":[{"type":"disagg-headers-handler"},{"type":"prefix-cache-scorer"},{"type":"queue-scorer"},{"type":"prefill-filter"},{"type":"decode-filter"},{"type":"max-score-picker"},{"parameters":{"nonCachedTokens":16},"type":"prefix-based-pd-decider"},{"parameters":{"deciders":{"prefill":"prefix-based-pd-decider"}},"type":"disagg-profile-handler"}],"schedulingProfiles":[{"name":"prefill","plugins":[{"pluginRef":"prefill-filter"},{"pluginRef":"max-score-picker"},{"pluginRef":"prefix-cache-scorer","weight":2},{"pluginRef":"queue-scorer","weight":1}]},{"name":"decode","plugins":[{"pluginRef":"decode-filter"},{"pluginRef":"max-score-picker"},{"pluginRef":"prefix-cache-scorer","weight":2},{"pluginRef":"queue-scorer","weight":1}]}]}` | EndpointPicker configuration. |
| config.featureGates | list | `[]` | featureGates enables optional EPP framework features. Leave empty unless a specific plugin requires a gate. |
| containerPorts.grpc | int | `9002` | gRPC port exposed by the main container. |
| containerPorts.grpcHealth | int | `9003` | gRPC health port exposed by the main container. |
| containerPorts.metrics | int | `9090` | Metrics port exposed by the main container. |
| containerPorts.zmq | int | `5557` | ZMQ port exposed by the main container. |
| extraArgs | list | `["--v=3","--zap-encoder=json","--zap-stacktrace-level=error","--metrics-endpoint-auth=false"]` | Extra arguments added to the main container's default arguments. If `args` is set, this value is ignored. |
| extraEnvVars | list | `[]` | Extra environment variables for the main container. |
| extraManifests | list | `[]` | Extra manifests to be deployed alongside the main application. |
| extraVolumeMounts | list | `[]` | Extra volumeMounts for the main container. |
| extraVolumes | list | `[]` | Extra volumes for the pod. |
| fullnameOverride | string | `""` | Full name override. |
| gateway.bbr | object | `{"header":"X-Gateway-Model-Name","models":[]}` | Body-based router configuration. |
| gateway.bbr.header | string | `"X-Gateway-Model-Name"` | HTTP header name to match (e.g. X-Gateway-Model-Name). |
| gateway.bbr.models | list | `[]` | List of model values to match (e.g. ["meta-llama/Llama-3.2-1B-Instruct"]). |
| gateway.gatewayClassName | string | `"istio"` | Gateway class name. |
| gateway.labels | object | `{}` | Labels applied to the gateway-related resources (e.g., HTTPRoute, InferencePool). |
| gateway.name | string | `""` | Gateway name to bind to. |
| gateway.namespace | string | `""` | Gateway namespace to bind to. If not set, it defaults to the release namespace. |
| global | object | `{"imagePullSecrets":[]}` | Global values shared across all sub-charts if the value's key matches. |
| global.imagePullSecrets | list | `[]` | Image pull secrets. |
| gracefulShutdownTimeout | string | `""` | Drain budget for the controller-runtime manager after SIGTERM. Accepts a Go duration string (e.g. "120s", "5m"). When empty, the controller-runtime default (30s) is used, which may force-cancel long-running gRPC streams. Set any negative duration (e.g. "-1s") to wait indefinitely. |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| image.pullSecrets | list | `[]` | Image pull secrets. |
| image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/heimdall-inference-scheduler"` | Image repository. |
| image.tag | string | `""` | Image tag (defaults to chart appVersion if not set). |
| inferencePool.matchLabels | object | `{}` | Label selector for model serving pods. If not set, defaults to `mif.moreh.io/pool: <inferencePoolName>`. |
| inferencePool.targetPorts | list | `[{"number":8000}]` | Target port number for model serving pods. |
| livenessProbe | object | `{"failureThreshold":3,"grpc":{"port":9003,"service":"liveness"},"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` | Liveness probe for the main container. Uses the "liveness" service to prevent unnecessary restarts of non-leader pods when leader election is enabled. |
| nameOverride | string | `""` | Chart name override. |
| namespaceOverride | string | `""` | Namespace override. |
| nodeSelector | object | `{}` | Node selector for pods scheduling. |
| podAnnotations | object | `{}` | Annotations applied to all pods. |
| podLabels | object | `{}` | Labels applied to all pods. |
| poolPodMonitor.enabled | bool | `true` | Whether to create a PodMonitor for Prometheus Operator. |
| poolPodMonitor.interval | string | `"15s"` | Interval between scrapes. |
| poolPodMonitor.labels | object | `{"release":"mif"}` | Labels applied to the PodMonitor. |
| readinessProbe | object | `{"failureThreshold":3,"grpc":{"port":9003,"service":"envoy.service.ext_proc.v3.ExternalProcessor"},"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` | Readiness probe for the main container. |
| replicas | int | `1` | Number of replicas. |
| resources | object | `{}` | Resource requests and limits for the main container. |
| serviceAccount.annotations | object | `{}` | Annotations added to the ServiceAccount. |
| serviceAccount.automount | bool | `true` | Whether to automatically mount API credentials. |
| serviceAccount.create | bool | `true` | Whether to create a ServiceAccount. |
| serviceAccount.name | string | `""` | Name of the ServiceAccount (auto-generated if empty and create is true). |
| serviceMonitor.enabled | bool | `true` | Whether to create a ServiceMonitor for Prometheus Operator. |
| serviceMonitor.interval | string | `"15s"` | Interval between scrapes. |
| serviceMonitor.labels | object | `{"release":"mif"}` | Labels applied to the ServiceMonitor. |
| startupProbe | object | `{"failureThreshold":30,"grpc":{"port":9003,"service":"envoy.service.ext_proc.v3.ExternalProcessor"},"initialDelaySeconds":10,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":5}` | Startup probe for the main container. Protects slow-starting containers (e.g., large tokenizer loading) from being killed by liveness/readiness probes before they are fully initialized. |
| terminationGracePeriodSeconds | int | `130` | Termination grace period in seconds. The kubelet sends SIGKILL after this many seconds following SIGTERM. Should be >= the manager's drain budget (`gracefulShutdownTimeout`) plus a small safety buffer. |
| tolerations | list | `[]` | Tolerations for pods scheduling. |
| tracing.enabled | bool | `false` | Whether to enable OpenTelemetry tracing. |
| tracing.exporter.endpoint | string | `""` | Endpoint for the OTLP exporter. |
| tracing.sampler.argument | float | `0.1` | Sampler argument. |
| tracing.sampler.type | string | `"parentbased_traceidratio"` | Sampler type. Supported types: parentbased_traceidratio |
| udsTokenizer.args | list | `[]` | Arguments applied to the UDS tokenizer container. |
| udsTokenizer.command | list | `[]` | Command applied to the UDS tokenizer container. |
| udsTokenizer.enabled | bool | `false` | Whether to enable UDS tokenizer sidecar. |
| udsTokenizer.extraEnvVars | list | `[]` | Extra environment variables for the UDS tokenizer container. |
| udsTokenizer.image.pullPolicy | string | `"IfNotPresent"` | Image pull policy. |
| udsTokenizer.image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/heimdall-uds-tokenizer"` | Image repository. |
| udsTokenizer.image.tag | string | `"v0.1.0"` | Image tag. |
| udsTokenizer.resources | object | `{}` | Resource requests and limits for the UDS tokenizer container. |
| updateStrategy.type | string | `"RollingUpdate"` | Update strategy for deployment. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
