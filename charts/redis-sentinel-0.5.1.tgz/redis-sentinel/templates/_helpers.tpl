{{/*
Expand the name of the chart.
*/}}
{{- define "redis-sentinel.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fully qualified app name (≤63 chars). Standard Helm dedup pattern.
*/}}
{{- define "redis-sentinel.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart label.
*/}}
{{- define "redis-sentinel.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels.
*/}}
{{- define "redis-sentinel.labels" -}}
helm.sh/chart: {{ include "redis-sentinel.chart" . }}
{{ include "redis-sentinel.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels.
*/}}
{{- define "redis-sentinel.selectorLabels" -}}
app.kubernetes.io/name: {{ include "redis-sentinel.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Container image string from .Values.image.
*/}}
{{- define "redis-sentinel.image" -}}
{{- printf "%s/%s:%s" .Values.image.registry .Values.image.repository .Values.image.tag -}}
{{- end -}}

{{/*
Headless service name (StatefulSet's serviceName).
*/}}
{{- define "redis-sentinel.headlessServiceName" -}}
{{- printf "%s-headless" (include "redis-sentinel.fullname" .) -}}
{{- end -}}

{{/*
Auth secret name: existing if specified, otherwise the default generated.
The default generated secret is named "<fullname>-auth".
*/}}
{{- define "redis-sentinel.authSecretName" -}}
{{- if .Values.auth.existingSecret -}}
{{- .Values.auth.existingSecret -}}
{{- else -}}
{{- printf "%s-auth" (include "redis-sentinel.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Scripts ConfigMap name.
*/}}
{{- define "redis-sentinel.scriptsConfigMapName" -}}
{{- printf "%s-scripts" (include "redis-sentinel.fullname" .) -}}
{{- end -}}

{{/*
Sentinel ClusterIP service name (used by extra read replicas for
SENTINEL get-master-addr-by-name discovery).
*/}}
{{- define "redis-sentinel.sentinelServiceName" -}}
{{- include "redis-sentinel.fullname" . -}}
{{- end -}}

{{/*
Extra read-replica StatefulSet name.
*/}}
{{- define "redis-sentinel.extraFullname" -}}
{{- printf "%s-extra" (include "redis-sentinel.fullname" .) -}}
{{- end -}}
