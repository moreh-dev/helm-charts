{{/*
Chart fullname (respects name/fullname overrides). Also the Deployment / SA /
schedulerName / leader-election resourceName — keep it stable.
*/}}
{{- define "tt-topology-scheduler.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end }}

{{/*
Target namespace (value-driven, not .Release.Namespace, because the
leader-election resourceNamespace in the scheduler config must match).
*/}}
{{- define "tt-topology-scheduler.namespace" -}}
{{- .Values.namespace -}}
{{- end }}

{{/*
Full image reference; tag defaults to the (CI-stamped) chart appVersion.
*/}}
{{- define "tt-topology-scheduler.image" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{ .Values.image.repository }}:{{ $tag }}
{{- end }}

{{/*
Merged image pull secrets (chart-local + umbrella global).
*/}}
{{- define "tt-topology-scheduler.imagePullSecrets" -}}
{{- $secrets := concat (.Values.imagePullSecrets | default list) ((.Values.global).imagePullSecrets | default list) -}}
{{- if $secrets }}
imagePullSecrets:
{{- range $secrets }}
- {{ toYaml . | nindent 2 | trim }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels applied to every resource.
*/}}
{{- define "tt-topology-scheduler.labels" -}}
app.kubernetes.io/name: {{ include "tt-topology-scheduler.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels for the scheduler pods (kept as `app:` to match the existing
Deployment/Service selectors and PodMonitor).
*/}}
{{- define "tt-topology-scheduler.selectorLabels" -}}
app: {{ include "tt-topology-scheduler.fullname" . }}
{{- end }}
