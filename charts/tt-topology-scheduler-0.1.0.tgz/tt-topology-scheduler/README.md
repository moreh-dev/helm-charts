# tt-topology-scheduler Helm Chart

Installs a **second kube-scheduler** carrying the `TTTopologyPlacement` plugin. TT
gang pods opt in with `spec.schedulerName: tt-topology-scheduler`; everything else
stays on the cluster's default scheduler.

This chart is **self-contained**: it installs standalone, with no `tt-mif` umbrella
and no Fabric Manager. It is also consumed as a subchart by the `tt-mif` umbrella —
both paths render the same objects.

---

## What the chart manages

| Resource | Kind | Namespace |
|---|---|---|
| `tt-scheduler` | Namespace | — |
| `tt-topology-scheduler` | ServiceAccount | tt-scheduler |
| `tt-topology-scheduler-config` | ConfigMap (`KubeSchedulerConfiguration`) | tt-scheduler |
| `tt-topology-scheduler` | ClusterRole | — |
| `tt-topology-scheduler-kube` | ClusterRoleBinding (`system:kube-scheduler`) | — |
| `tt-topology-scheduler-volume` | ClusterRoleBinding (`system:volume-scheduler`) | — |
| `tt-topology-scheduler-extra` | ClusterRoleBinding (own leader-election lease) | — |
| `tt-topology-scheduler-authreader` | RoleBinding (`extension-apiserver-authentication-reader`) | **kube-system** |
| `tt-topology-scheduler` | Deployment | tt-scheduler |
| `tt-fabric-topology` | ConfigMap (the cabling graph) | tt-scheduler |

A second scheduler needs **all three** of `system:kube-scheduler`,
`system:volume-scheduler` and its own lease RBAC — plus the `kube-system`
authreader RoleBinding — or it will start and then fail on its first pod.

With `topologyGenerator.enabled=true` the chart adds a Job, ServiceAccount, Role
and RoleBinding named `tt-topology-scheduler-topology-gen` in `tt-scheduler`.

---

## Prerequisites

1. **Kubernetes v1.35.x.** The plugin is compiled against the v1.35.4 scheduler
   framework (KEP-4262 moved it to `k8s.io/kube-scheduler/framework`). A different
   minor will not load.
2. **DRA enabled** on the cluster (`resource.k8s.io/v1`). The in-tree
   `DynamicResources` plugin runs inside this same binary, so DRA claims for TT
   gang pods are allocated here, not by the default scheduler.
3. **`tt-dra-plugin` running.** *Not a Helm dependency — a data prerequisite.*
   Since 2026-08-26 the placer learns which nodes hold TT devices, and of which
   model, from the **DRA ResourceSlice device attributes** the plugin publishes
   (`tenstorrent.com/model`), replacing the retired `tt-node-detector` labels.
   Install this chart alone and the pod starts and wins leader election — but it
   places nothing, because it sees no hosts. Verify with:

   ```bash
   kubectl get resourceslices
   ```

**Not** a prerequisite: TT Fabric Manager. Placement has been FM-free since
2026-07-21 (see `../../FM-FREE-PLACER.md`). FM is only dialled by the optional
`topologyGenerator` Job, which is off by default.

---

## Install — standalone

```bash
helm repo add moreh https://moreh-dev.github.io/helm-charts
helm repo update moreh
helm search repo moreh/tt-topology-scheduler        # list available versions

cp values-standalone.yaml.example values-standalone.yaml   # then edit the graph
helm install tts moreh/tt-topology-scheduler \
  --version <X.Y.Z> \
  -f values-standalone.yaml
```

`values-standalone.yaml.example` is annotated and covers the only two things that
are genuinely per-cluster: the cabling graph, and (air-gapped only) the registry.

**If anything named `tt-topology-scheduler` already exists on the cluster**, Helm
refuses to adopt objects it does not own and the install fails with *"exists and
cannot be imported into the current release"*. Two different situations, with two
different answers — find out which you are in first:

```bash
kubectl -n tt-scheduler get deploy tt-topology-scheduler \
  -o jsonpath='{.metadata.annotations.meta\.helm\.sh/release-name}{"\n"}'
```

- **Empty, but the namespace exists** — something created the namespace by hand
  (`deploy-mif.sh` does `kubectl create ns tt-scheduler`) while nothing owns the
  workload. Add `--set createNamespace=false` and install normally.
- **A release name comes back** (typically `tt-mif`) — the umbrella already owns
  this scheduler, including the **cluster-scoped** ClusterRole and bindings, so
  changing the namespace does not help either. Do **not** install standalone
  alongside it: that is a *migration*, not an install. Either keep using the
  umbrella (which pulls this same chart from the shelf), or remove the umbrella's
  copy first with `--set tt-topology-scheduler.enabled=false` on the umbrella
  before installing standalone.

### From a source checkout

```bash
helm lint  helm/tt-topology-scheduler
helm template tts helm/tt-topology-scheduler -f <your-values>.yaml   # render first
helm install  tts helm/tt-topology-scheduler -f <your-values>.yaml
```

### As part of the tt-mif umbrella

Nothing to do — the umbrella installs it under the `tt-topology-scheduler.*` values
key and supplies the FM address for the generator Job. See `deploy/helm/tt-mif/`.

---

## After install

```bash
# 1. Running and leader-elected?
kubectl -n tt-scheduler get deploy,pods
kubectl -n tt-scheduler logs deploy/tt-topology-scheduler | grep -i "starts to work"

# 2. What cabling does it believe in?
kubectl -n tt-scheduler get cm tt-fabric-topology -o jsonpath='{.data.topology}'

# 3. Send a gang to it
#    spec.schedulerName: tt-topology-scheduler
#    annotations: tt.moreh.io/device-topology, tt.moreh.io/model
```

**The graph is read once, at startup.** After changing the ConfigMap — by hand or
via the generator — you must restart the Deployment or nothing changes:

```bash
kubectl -n tt-scheduler rollout restart deploy/tt-topology-scheduler
```

---

## The cabling graph is load-bearing

`tt-fabric-topology` is the **sole** source of truth for which machines are wired
together. The placer trusts it completely; there is no cross-check at schedule
time. An edge that does not physically exist will install cleanly, schedule
cleanly, and then fail inside the engine as a fabric error — late, and pointing at
the wrong component.

**It has two forms, and they are not equivalent:**

| Form | Written by | Stored as | Capability |
|---|---|---|---|
| PhysicalSystemDescriptor JSON, gzipped | the generator Job | `binaryData.topology` | **preferred** — carries per-chip positions and cable endpoints, so the placer can derive each seam's mesh axis |
| `hostA hostB` edge list, plain text | `fabricTopology.inline` | `data.topology` | legacy fallback — still parsed, but with no axes the placer **cannot reject** a request needing two host dimensions |

`pkg/fabric/compress.go` reads all three (gzipped JSON, plain JSON, edge list), so
`inline` is safe — it is just less capable. A live cluster runs the gzipped-JSON
form. Prefer generating from FM; use `inline` to bootstrap, to pin a known-good
graph, or where there is no FM.

To regenerate it (**devices must be IDLE** — FM needs a full discovery, and the Job
refuses to write a degraded one):

```bash
helm upgrade tts moreh/tt-topology-scheduler --reuse-values \
  --set topologyGenerator.enabled=true \
  --set topologyGenerator.fmControllerAddr=<fm-controller>:50052

kubectl -n tt-scheduler logs job/tt-topology-scheduler-topology-gen
kubectl -n tt-scheduler rollout restart deploy/tt-topology-scheduler
```

Jobs are immutable: to re-run, delete the Job first. Find the FM address with
`kubectl get svc -A | grep -i fabric-manager`.

---

## Values

| Key | Default | What it does |
|---|---|---|
| `nameOverride` | `""` | Chart name override. |
| `fullnameOverride` | `""` | Full name override. **This is also the `schedulerName`** — change it and every gang pod must change with it. |
| `global.imagePullSecrets` | `[]` | Pull secrets shared with sibling subcharts under the umbrella. |
| `namespace` | `tt-scheduler` | Namespace for the scheduler, its RBAC, config and graph. Must match the leader-election `resourceNamespace`. |
| `createNamespace` | `true` | Render the Namespace object. `false` when GitOps or the umbrella owns it. |
| `image.repository` | `ghcr.io/moreh-dev/tt-topology-scheduler` | Holds both `/tt-topology-scheduler` and `/gen-fabric-topology`. |
| `image.tag` | `""` | Empty ⇒ the chart's `appVersion`. Use a mutable tag like `local` only with `pullPolicy: Always`. |
| `image.pullPolicy` | `IfNotPresent` | |
| `imagePullSecrets` | `[]` | Chart-local pull secrets; merged with `global.imagePullSecrets`. |
| `replicas` | `1` | Leader election means one is active; `>1` is warm standby. |
| `logLevel` | `"2"` | klog `--v`. `2` shows placement and gang decisions. |
| `resources` | `{}` | Requests/limits for the scheduler container. |
| `nodeSelector` | `{}` | |
| `tolerations` | `[]` | |
| `affinity` | `{}` | |
| `fabricTopology.create` | `true` | Render the `tt-fabric-topology` ConfigMap (pre-install hook, `resource-policy: keep`). Keep `true` — the scheduler hard-requires the file at boot and crash-loops without it. An empty graph is fine. |
| `fabricTopology.inline` | `""` | The graph itself: one `hostA hostB` edge per line, or a PhysicalSystemDescriptor JSON. Empty ⇒ an empty graph, to be populated by the generator. **There is no `seed` key** — `inline` present or absent is the switch. |
| `topologyGenerator.enabled` | `false` | Render the generator Job + its RBAC. |
| `topologyGenerator.fmControllerAddr` | `""` | FM controller gRPC address (`:50052`, the always-on port — not the web UI). **Required when `enabled=true`; the chart refuses to render without it.** No default on purpose: the name and namespace depend on how FM was installed. |
| `topologyGenerator.backoffLimit` | `2` | |
| `topologyGenerator.activeDeadlineSeconds` | `120` | |
| `topologyGenerator.ttlSecondsAfterFinished` | `600` | How long the finished Job (and its logs) survive. |
| `rbac.create` | `true` | Create the ServiceAccount, ClusterRoles/Bindings and the `kube-system` authreader RoleBinding a second scheduler needs. |

Values carry `# --` doc comments in `values.yaml` in the `helm-docs` format; this
table is maintained by hand alongside them.

---

## Uninstall

```bash
helm uninstall tts
```

`tt-fabric-topology` carries `helm.sh/resource-policy: keep` and **survives** on
purpose — the graph is expensive to rebuild (it needs idle devices). Delete it
explicitly if you really want it gone:

```bash
kubectl -n tt-scheduler delete cm tt-fabric-topology
```

---

## See also

- `../../DESIGN.md` — why a scheduler plugin, and the four constraints it satisfies
- `../../FM-FREE-PLACER.md` — the static-graph placer, and the topology lifecycle
- `../../README.md` — the component: build, deploy, validation history
