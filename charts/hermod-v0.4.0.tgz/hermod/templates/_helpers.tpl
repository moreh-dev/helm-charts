{{/*
Selector labels for match-label fields. Must be stable across upgrades.
*/}}
{{- define "hermod.matchLabels" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Full label set applied to all generated resources.
*/}}
{{- define "hermod.labels" -}}
{{- range $name, $value := .Values.commonLabels -}}
{{ $name }}: {{ tpl $value $ }}
{{ end -}}
helm.sh/chart: {{ include "common.names.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- end }}
app.kubernetes.io/part-of: mif
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ include "hermod.matchLabels" . }}
{{- end }}

{{/*
ServiceAccount name. Falls back to the chart fullname when creating.
*/}}
{{/*
Name of the identity Secondary clusters authenticate as against this cluster.
Distinct from hermod.serviceAccountName, which is what the operator here runs as.
*/}}
{{- define "hermod.secondaryAccessName" -}}
{{- $name := default (printf "%s-secondary-access" (include "common.names.fullname" .)) .Values.primary.secondaryAccess.name -}}
{{- if eq $name (include "hermod.serviceAccountName" .) -}}
{{- fail (printf "primary.secondaryAccess.name must differ from the operator's ServiceAccount (%q). A ClusterRoleBinding on that name would add the secondary-access rules to the operator's own identity, and the token handed to each Secondary would then carry everything the operator can do here -- including creating Artifacts, which is exactly what this identity exists to withhold." $name) -}}
{{- end -}}
{{- $name -}}
{{- end }}

{{- define "hermod.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Names the controller manages directly in download/validation/check/cleanup
Jobs. Users cannot override these via `downloader.extraEnvVars` /
`hf.defaultEnvVars` — setting any of these triggers a chart-level `fail`
because overriding them would break controller invariants (PVC mount path,
Artifact source coordinates, etc.).

Must stay in sync with `ReservedJobEnvKeys()` in
`internal/controller/artifact_controller.go`.
*/}}
{{- define "hermod.reservedJobEnvNames" -}}
HF_HOME,REPO_ID,REPO_TYPE,MODEL_ID,REVISION,ARTIFACT_DIR,ARTIFACT_NAME,S3_BUCKET,S3_KEY,S3_REGION,S3_ENDPOINT,S3_FORCE_PATH_STYLE,S3_INSECURE,HF_DOWNLOAD_MAX_WORKERS,VALIDATION_MODE,VALIDATION_PARALLELISM,ARTIFACT_UPLOAD_NAME,HF_INCLUDE_PATTERNS,HF_EXCLUDE_PATTERNS,HERMOD_ARTIFACT_NAME,ARTIFACT_REPO_DIR,ARTIFACT_REVISION,HERMOD_S3_SOURCE,HERMOD_OWN_DIGEST,S3_LEGACY_FALLBACK
{{- end }}

{{/*
Fail if any EnvVar list contains:
  - an empty name,
  - a name that violates the POSIX env-var pattern (^[A-Za-z_][A-Za-z0-9_]*$),
  - or a reserved key that the controller manages as a Job invariant.
Mirrors the startup-time checks in cmd/main.go `validateInjectedEnvVars`
(regex lives in `controller.EnvNamePattern`) so a chart misconfiguration
fails the `helm install/upgrade` instead of the operator crashing at
runtime with CrashLoopBackOff.

Invoked from deployment.helm.yaml for both `downloader.extraEnvVars` and
`downloader.hf.defaultEnvVars`.

Takes a dict with:
  - .name  : values path shown in the error message
  - .list  : the EnvVar list to check
*/}}
{{- define "hermod.assertEnvVarsAllowed" -}}
{{- $reserved := splitList "," (include "hermod.reservedJobEnvNames" .) -}}
{{- $pattern := "^[A-Za-z_][A-Za-z0-9_]*$" -}}
{{- range .list -}}
{{- if eq .name "" -}}
{{- fail (printf "%s contains an env var with an empty name" $.name) -}}
{{- end -}}
{{- if not (regexMatch $pattern .name) -}}
{{- fail (printf "%s contains invalid env var name %q (must match %s)" $.name .name $pattern) -}}
{{- end -}}
{{- if has .name $reserved -}}
{{- fail (printf "%s contains reserved key %q which is managed by the controller and cannot be overridden" $.name .name) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Allowed values of downloader.validation.defaultMode, and the pattern
downloader.validation.defaultParallelism must match. Both mirror
resolveValidationDefaults in cmd/main.go, which applies the same checks at
operator startup; cmd/main_test.go reads this file and fails when the two
drift. Kept as their own defines so that test can parse them.
*/}}
{{- define "hermod.validationModes" -}}
Full,SafetensorsOnly,Skip
{{- end }}

{{- define "hermod.validationParallelismPattern" -}}
^(auto|[1-9]|[12][0-9]|3[0-2])$
{{- end }}

{{/*
Fail the render when downloader.validation.defaultMode or
downloader.validation.defaultParallelism holds a value the operator would
refuse. Runs on every role on purpose: deployment.helm.yaml does not pass
either value to a Secondary Pod, so the operator cannot check them there and a
typo in a Secondary values file would otherwise surface only when that cluster
is promoted to Primary. Empty values pass — the operator applies its own
Full / auto fallback.
*/}}
{{- define "hermod.assertValidationDefaults" -}}
{{- $mode := "" -}}
{{- if not (kindIs "invalid" .Values.downloader.validation.defaultMode) -}}
{{- $mode = trim (toString .Values.downloader.validation.defaultMode) -}}
{{- end -}}
{{- $modes := splitList "," (include "hermod.validationModes" .) -}}
{{- if and (ne $mode "") (not (has $mode $modes)) -}}
{{- fail (printf "downloader.validation.defaultMode must be one of %s or empty, got %q" (join ", " $modes) $mode) -}}
{{- end -}}
{{- $parallelism := "" -}}
{{- if not (kindIs "invalid" .Values.downloader.validation.defaultParallelism) -}}
{{- $parallelism = trim (toString .Values.downloader.validation.defaultParallelism) -}}
{{- end -}}
{{- if and (ne $parallelism "") (not (regexMatch (include "hermod.validationParallelismPattern" .) $parallelism)) -}}
{{- fail (printf "downloader.validation.defaultParallelism must be \"auto\" or an integer in [1, 32], got %q" $parallelism) -}}
{{- end -}}
{{- end }}

{{/*
controller.role with surrounding whitespace removed. resolveRole in cmd/main.go
trims before matching, so a values file carrying " Secondary " starts a
Secondary operator; comparing the raw value here would send the Pod spec and
the webhook policy down the Primary branch instead. Every role comparison in
this chart goes through this, and so does the --role flag itself, so the value
the operator resolves and the value the chart branched on cannot differ.
*/}}
{{- define "hermod.controllerRole" -}}
{{- trim (toString .Values.controller.role) -}}
{{- end }}
