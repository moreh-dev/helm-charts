{{/*
Selector labels for match-label fields. Must be stable across upgrades.
*/}}
{{- define "hermod.matchLabels" -}}
app.kubernetes.io/name: {{ include "common.names.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Full label set applied to all generated resources.
*/}}
{{- define "hermod.labels" -}}
{{- range $name, $value := .Values.commonLabels -}}
{{ $name }}: {{ tpl $value $ }}
{{ end -}}
helm.sh/chart: {{ include "common.names.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- end }}
app.kubernetes.io/part-of: mif
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ include "hermod.matchLabels" . }}
{{- end }}

{{/*
ServiceAccount name. Falls back to the chart fullname when creating.
*/}}
{{- define "hermod.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "common.names.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Names the controller manages directly in download/validation/check/cleanup
Jobs. Users cannot override these via `downloader.extraEnvVars` /
`hf.defaultEnvVars` — setting any of these triggers a chart-level `fail`
because overriding them would break controller invariants (PVC mount path,
Artifact source coordinates, etc.).

Must stay in sync with `ReservedJobEnvKeys()` in
`internal/controller/artifact_controller.go`.
*/}}
{{- define "hermod.reservedJobEnvNames" -}}
HF_HOME,REPO_ID,REPO_TYPE,MODEL_ID,REVISION,ARTIFACT_DIR,ARTIFACT_NAME,S3_BUCKET,S3_KEY,S3_REGION,S3_ENDPOINT,S3_FORCE_PATH_STYLE,S3_INSECURE,HF_DOWNLOAD_MAX_WORKERS,VALIDATION_MODE,VALIDATION_PARALLELISM,ARTIFACT_UPLOAD_NAME,HF_INCLUDE_PATTERNS,HF_EXCLUDE_PATTERNS,HERMOD_ARTIFACT_NAME,ARTIFACT_REPO_DIR,ARTIFACT_REVISION
{{- end }}

{{/*
Fail if any EnvVar list contains:
  - an empty name,
  - a name that violates the POSIX env-var pattern (^[A-Za-z_][A-Za-z0-9_]*$),
  - or a reserved key that the controller manages as a Job invariant.
Mirrors the startup-time checks in cmd/main.go `validateInjectedEnvVars`
(regex lives in `controller.EnvNamePattern`) so a chart misconfiguration
fails the `helm install/upgrade` instead of the operator crashing at
runtime with CrashLoopBackOff.

Invoked from deployment.helm.yaml for both `downloader.extraEnvVars` and
`downloader.hf.defaultEnvVars`.

Takes a dict with:
  - .name  : values path shown in the error message
  - .list  : the EnvVar list to check
*/}}
{{- define "hermod.assertEnvVarsAllowed" -}}
{{- $reserved := splitList "," (include "hermod.reservedJobEnvNames" .) -}}
{{- $pattern := "^[A-Za-z_][A-Za-z0-9_]*$" -}}
{{- range .list -}}
{{- if eq .name "" -}}
{{- fail (printf "%s contains an env var with an empty name" $.name) -}}
{{- end -}}
{{- if not (regexMatch $pattern .name) -}}
{{- fail (printf "%s contains invalid env var name %q (must match %s)" $.name .name $pattern) -}}
{{- end -}}
{{- if has .name $reserved -}}
{{- fail (printf "%s contains reserved key %q which is managed by the controller and cannot be overridden" $.name .name) -}}
{{- end -}}
{{- end -}}
{{- end }}
