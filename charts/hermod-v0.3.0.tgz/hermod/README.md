# hermod

Hermod - LLM artifact lifecycle operator for Kubernetes

![Version: 0.0.0](https://img.shields.io/badge/Version-0.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.0.0](https://img.shields.io/badge/AppVersion-0.0.0-informational?style=flat-square)

**Homepage:** <https://github.com/moreh-dev/hermod>

## Prerequisites

- Kubernetes 1.32+
- [cert-manager](https://cert-manager.io/) installed cluster-wide
- The `hermod-crd` chart installed first:

  ```
  helm upgrade -i hermod-crd deploy/helm/hermod-crd
  ```

## Install

```
helm dependency update deploy/helm/hermod
helm upgrade -i hermod deploy/helm/hermod \
  --namespace hermod-system --create-namespace
```

The operator detects its install namespace at runtime via the Downward API
(`POD_NAMESPACE`); you may install into any namespace, and all generated
resources (origin PVCs, download Jobs, mirror Secrets) are placed there.
`spec.persistentVolumeClaimRef` on an `ArtifactRepository` must reference a
PVC in that same install namespace.

## HuggingFace token (private models)

Create a Kubernetes Secret first, then reference it from
`downloader.hf.defaultEnvVars` so every HF Job inherits the token as a
default. Per-Artifact `spec.source.huggingface.tokenSecretRef` overrides
this when set.

```
kubectl -n hermod-system create secret generic hf-token \
  --from-literal=HF_TOKEN=<hf_xxx>

helm upgrade hermod deploy/helm/hermod \
  --namespace hermod-system --reuse-values --values - <<VALUES
downloader:
  hf:
    defaultEnvVars:
      - name: HF_TOKEN
        valueFrom:
          secretKeyRef:
            name: hf-token
            key: HF_TOKEN
VALUES
```

If the whole Secret should be injected as-is, use the `envFrom` shortcut:

```
helm upgrade hermod deploy/helm/hermod \
  --namespace hermod-system --reuse-values \
  --set downloader.hf.defaultEnvVarsSecret=hf-token
```

## Migration from pre-0.1 (monolithic chart)

| Old key                                   | New key                                            |
|-------------------------------------------|----------------------------------------------------|
| `manager.replicas`                        | `controller.replicas`                              |
| `manager.image.*`                         | `controller.image.*` (`pullSecrets` added)         |
| `manager.args`                            | `controller.args` / `controller.extraArgs`         |
| `manager.env` + `manager.envOverrides`    | `controller.extraEnvVars` (supports `valueFrom`)   |
| `manager.imagePullSecrets`                | `controller.image.pullSecrets`, `global.imagePullSecrets` |
| `manager.resources/nodeSelector/...`      | `controller.resources/nodeSelector/...`            |
| `controller.downloaderImage.*`            | `downloader.image.*`                               |
| `controller.maxConcurrentDownloads`       | `downloader.maxConcurrentDownloads`                |
| `controller.downloadBandwidthLimit`       | `downloader.bandwidthLimit`                        |
| `controller.huggingface.defaultEnv` (map) | `downloader.hf.defaultEnvVars` (list of EnvVar, supports `valueFrom`) |
| `rbacHelpers.enable`                      | `rbacHelpers.enabled`                              |
| `crd.enable`, `crd.keep`                  | removed — install `hermod-crd` separately          |
| `metrics.enable`, `metrics.port`          | removed — metrics always on port 8443              |
| `certManager.enable`                      | removed — cert-manager must be pre-installed       |
| `webhook.enable/port/caBundle/certSecret` | removed — webhook is always on port 9443 (cert-manager-managed) |
| `serviceMonitor.enable`                   | `controller.metrics.serviceMonitor.enabled`        |

CRD schema: `spec.existingPvcRef` has been renamed to
`spec.persistentVolumeClaimRef`. Update existing `ArtifactRepository`
manifests accordingly.

### New keys in 0.1

The chart exposes two families of env-injection knobs:

| Key                                   | Scope                          | Priority              |
|---------------------------------------|--------------------------------|-----------------------|
| `downloader.extraEnvVars` (list)      | ALL downloader Jobs (HF, S3, check, cleanup) | OVERRIDE (bitnami convention — wins over per-Artifact) |
| `downloader.extraEnvVarsSecret` (str) | ALL downloader Jobs            | envFrom (K8s-native low priority) |
| `downloader.hf.defaultEnvVars` (list) | HF download / validation Jobs only | DEFAULT (per-Artifact `spec.source.huggingface.env` / `tokenSecretRef` overrides) |
| `downloader.hf.defaultEnvVarsSecret` (str) | HF download / validation Jobs only | envFrom (K8s-native low priority) |

Typical patterns:

- Cluster-wide HuggingFace mirror with per-Artifact escape hatch:
  set `downloader.hf.defaultEnvVars: [{name: HF_ENDPOINT, value: https://mirror}]`.
- Shared fallback HF token that per-Artifact `tokenSecretRef` may override:
  set `downloader.hf.defaultEnvVars: [{name: HF_TOKEN, valueFrom: {secretKeyRef: {name: ..., key: HF_TOKEN}}}]`.
- Admin-enforced value that users cannot override: set `downloader.extraEnvVars`.

Inline `value: "<secret>"` literals end up in Helm release history —
prefer `valueFrom.secretKeyRef` for credentials.

Controller-managed keys (see `ReservedJobEnvKeys()` in
`internal/controller/artifact_controller.go` — `HF_HOME`, `REPO_ID`,
`REPO_TYPE`, `MODEL_ID`, `REVISION`, `ARTIFACT_DIR`, `ARTIFACT_NAME`,
`ARTIFACT_UPLOAD_NAME`, `S3_*`, `HF_DOWNLOAD_MAX_WORKERS`,
`VALIDATION_MODE`, `VALIDATION_PARALLELISM`, `HF_INCLUDE_PATTERNS`,
`HF_EXCLUDE_PATTERNS`, `HERMOD_ARTIFACT_NAME`) are reserved: setting them
in `extraEnvVars` or `hf.defaultEnvVars` makes `helm install/upgrade` fail
with a clear error.
The operator also rejects them on startup as a runtime safety net.

When both `extraEnvVarsSecret` and `hf.defaultEnvVarsSecret` are set,
`extraEnvVarsSecret` wins for duplicate keys (it is applied later in
the Pod's `envFrom` list).

## Requirements

Kubernetes: `>= 1.32.0-0`

| Repository | Name | Version |
|------------|------|---------|
| oci://registry-1.docker.io/bitnamicharts | common | 2.31.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| commonLabels | object | `{}` | Labels applied to every resource produced by the chart. |
| controller | object | `{"affinity":{},"args":[],"blobGC":{"confirmSeconds":10,"enabled":true},"command":[],"defaultDeletionPolicy":"Delete","extraArgs":[],"extraEnvVars":[],"extraVolumeMounts":[],"extraVolumes":[],"image":{"pullPolicy":"IfNotPresent","pullSecrets":[],"repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod","tag":""},"metrics":{"serviceMonitor":{"enabled":false,"interval":"","labels":{}}},"nodeSelector":{},"periodicVerification":{"enabled":false,"interval":"24h"},"podAnnotations":{},"podLabels":{},"replicaPVAccessMode":"ReadWriteMany","replicas":1,"resources":{},"revisionHistoryLimit":3,"role":"Primary","tolerations":[],"updateStrategy":{"type":"RollingUpdate"}}` | Controller-manager (operator) deployment configuration. |
| controller.affinity | object | `{}` | Affinity rules for operator pod scheduling. |
| controller.args | list | `[]` | Override container args. Empty uses the chart defaults. Chart defaults are: `--leader-elect`, `--health-probe-bind-address=:8081`, `--metrics-bind-address=:8443`, `--metrics-cert-path=/tmp/k8s-metrics-server/metrics-certs`, `--webhook-cert-path=/tmp/k8s-webhook-server/serving-certs`, `--role=<controller.role>`, `--max-concurrent-downloads=<downloader.maxConcurrentDownloads>` (when > 0), `--download-bandwidth-limit=<downloader.bandwidthLimit>` (when set), `--download-max-workers=<downloader.maxWorkers>` (when > 0), `--replica-pv-access-mode=<controller.replicaPVAccessMode>` (when set), `--download-stall-window=<downloader.stallWindow>` (when set), `--download-stall-sample-interval=<downloader.stallSampleInterval>` (when set), `--download-max-stall-restarts=<downloader.maxStallRestarts>`, `--blob-gc=false` (when `controller.blobGC.enabled` is false), `--blob-gc-confirm-seconds=<controller.blobGC.confirmSeconds>`, `--periodic-verification-enabled=true` + `--periodic-verification-interval=<controller.periodicVerification.interval>` (when `controller.periodicVerification.enabled` is true), `--primary-kubeconfig-secret=<secondary.primaryKubeconfigSecret>` (required when controller.role=Secondary), `--source-cluster-name=<secondary.sourceClusterName>` (when controller.role=Secondary), `--mirror-label-selector=<secondary.mirrorLabelSelector>` (when controller.role=Secondary and non-empty). |
| controller.blobGC.confirmSeconds | int | `10` | Seconds between the two samples of the unreferenced blob set. Only blobs unreferenced in both are removed, which guards the window where a download has placed a blob and not yet linked it into its snapshot. |
| controller.blobGC.enabled | bool | `true` | Reclaim unreferenced blobs when an Artifact is deleted. Without it a deletion frees only the snapshot's symlinks — a 100GB model returns a few KB, because the content lives in `blobs/` and only the links are removed.  A Secondary needs no change: the operator registers the Artifact controller only on the Primary role, so a Secondary never writes to the volume and never runs cleanup.  On a volume mounted by **two Primary clusters**, turning this off narrows one hazard but does not make the volume safe. The sweep itself reads the shared directory, so it keeps blobs any snapshot on the volume references — including the other cluster's. What neither this switch nor the sweep addresses is that cleanup deletes `snapshots/<commit>` and the refs entry regardless, and that deletion cannot see the other cluster's Artifacts either. Two Primaries on one volume need to become one Primary and N Secondaries; the switch is not a substitute. |
| controller.command | list | `[]` | Override container command. Empty uses the image entrypoint. |
| controller.defaultDeletionPolicy | string | `"Delete"` | Cluster-wide default for `deletionPolicy` on both ArtifactRepository and Artifact resources that do not set the field explicitly. Allowed values are "Delete" (cleanup on deletion) and "Retain" (preserve data on deletion). An empty string defers to the hard-coded "Delete" fallback inside the controller, matching pre-MAF-19695 behavior. Artifact inherits from ArtifactRepository first, then from this value. |
| controller.extraArgs | list | `[]` | Extra args appended to the chart defaults. Ignored when `args` is set. |
| controller.extraEnvVars | list | `[]` | Extra env vars for the operator container. Supports core/v1.EnvVar including `valueFrom.secretKeyRef` / `configMapKeyRef`. Prefer Secret references over inline values for credentials. |
| controller.extraVolumeMounts | list | `[]` | Extra volume mounts attached to the operator container. |
| controller.extraVolumes | list | `[]` | Extra volumes mounted into the operator pod. |
| controller.image.pullPolicy | string | `"IfNotPresent"` | Operator image pull policy. |
| controller.image.pullSecrets | list | `[]` | Image pull secrets for the operator image. |
| controller.image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod"` | Operator image repository. |
| controller.image.tag | string | `""` | Operator image tag. Defaults to `Chart.AppVersion` when empty. |
| controller.metrics.serviceMonitor.enabled | bool | `false` | Create a Prometheus-Operator ServiceMonitor for the metrics endpoint. Requires prometheus-operator to be installed in the cluster. |
| controller.metrics.serviceMonitor.interval | string | `""` | Scrape interval (e.g. "30s"). Empty uses the Prometheus default. |
| controller.metrics.serviceMonitor.labels | object | `{}` | Additional labels on the ServiceMonitor resource. |
| controller.nodeSelector | object | `{}` | Node selector for operator pod scheduling. |
| controller.periodicVerification.enabled | bool | `false` | Enable periodic existence verification of Ready artifacts. When true, the controller runs a lightweight, local-only Job at `interval` that confirms each Ready artifact's data is still present on the volume and transitions the Artifact to Failed (reason `DataLost`) if it is missing. The check makes no upstream (HuggingFace) call, so a network outage is never misread as data loss. Disabled by default. |
| controller.periodicVerification.interval | string | `"24h"` | How often a Ready artifact's data is re-verified, as a Go duration (e.g. "24h", "12h"). Only used when `enabled` is true. |
| controller.podAnnotations | object | `{}` | Annotations applied to operator pods. |
| controller.podLabels | object | `{}` | Additional labels applied to operator pods. |
| controller.replicaPVAccessMode | string | `"ReadWriteMany"` | AccessMode assigned to replica PV/PVCs provisioned in target namespaces by the ArtifactRepository controller. Allowed:  - "ReadWriteMany" (default): inference Pods can write to the mounted    volume. Needed for frameworks that cache locally (transformers'    trust_remote_code module cache under HF_MODULES_CACHE, PyTorch    bytecode, HF metadata, etc.) without a separate writable overlay.  - "ReadOnlyMany": strict multi-tenant mode. Replicas reject writes    at both the K8s level (accessModes) and the CSI level (ReadOnly).    Workloads that need local caches must mount an emptyDir overlay    (e.g. `HF_MODULES_CACHE=/tmp/hf-modules`). Note: this value only affects replica PV/PVCs created AFTER a chart upgrade. Existing replicas keep their original accessMode until manually recreated (delete PV/PVC → controller re-provisions). The origin PVC in the operator namespace is always ReadWriteMany regardless of this setting. |
| controller.replicas | int | `1` | Number of replicas. |
| controller.resources | object | `{}` | Resource requests and limits for the operator container. |
| controller.revisionHistoryLimit | int | `3` | Number of old ReplicaSets to retain for rollback history. |
| controller.role | string | `"Primary"` | Cluster role for this operator. "Primary" runs the full download/validate lifecycle; "Secondary" mirrors Artifact status watched from a Primary cluster and registers no download path. |
| controller.tolerations | list | `[]` | Tolerations for operator pod scheduling. |
| controller.updateStrategy.type | string | `"RollingUpdate"` | Deployment update strategy type. |
| downloader | object | `{"bandwidthLimit":"","extraEnvVars":[],"extraEnvVarsSecret":"","hf":{"defaultEnvVars":[],"defaultEnvVarsSecret":"","disableXet":false},"image":{"pullPolicy":"IfNotPresent","repository":"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod-downloader","tag":""},"job":{"resources":{"requests":{"cpu":"100m","memory":"256Mi"}}},"maxConcurrentDownloads":3,"maxStallRestarts":3,"maxWorkers":8,"s3":{"defaultProfileName":""},"stallSampleInterval":"15m","stallWindow":"1h","validation":{"defaultMode":"Full","defaultParallelism":"auto"}}` | Downloader Job configuration. The operator uses these values when spawning download Jobs for each Artifact. |
| downloader.bandwidthLimit | string | `""` | Per-Job bandwidth limit (e.g. "100Mi", "1Gi"). Empty means unlimited. |
| downloader.extraEnvVars | list | `[]` | Extra env vars injected into EVERY download Job (check, validation, download, cleanup). Follows the bitnami convention: these are applied LAST and OVERRIDE every other source of the same key — chart defaults, per-Artifact spec values, and the connection fields an S3 Artifact resolves from its S3Profile. Use this when the admin needs to force a value across all Artifacts regardless of user configuration.  Supports the full core/v1.EnvVar shape — prefer `valueFrom.secretKeyRef` over `value:` for credentials; plain `value:` literals end up in Helm release history and any git-committed values file.  Example (force a cluster-wide telemetry endpoint):   extraEnvVars:     - name: OTEL_EXPORTER_ENDPOINT       value: https://otel.internal |
| downloader.extraEnvVarsSecret | string | `""` | Name of an existing Secret to `envFrom` on every download Job (bitnami convention). Since `envFrom` has lower priority than `env` in Kubernetes, values here act as defaults that any explicit env var (chart-hardcoded, per-Artifact spec, or `extraEnvVars`) can override. When both `extraEnvVarsSecret` and `hf.defaultEnvVarsSecret` are set, `extraEnvVarsSecret` wins for duplicate keys because it is applied AFTER the HF Secret in the Pod's `envFrom` list (K8s merges in order). |
| downloader.hf.defaultEnvVars | list | `[]` | Default HF env vars prepended to every HuggingFace download / validation Job. Supports full core/v1.EnvVar (valueFrom.secretKeyRef etc.). Per-Artifact `spec.source.huggingface.env` and `tokenSecretRef` override matching keys.  Example (private mirror + shared team token):   defaultEnvVars:     - name: HF_ENDPOINT       value: https://hf-mirror.corp.internal     - name: HF_TOKEN       valueFrom:         secretKeyRef:           name: hermod-hf-token           key: HF_TOKEN |
| downloader.hf.defaultEnvVarsSecret | string | `""` | Name of an existing Secret to `envFrom` on every HF download / validation Job. Keys in the Secret are injected as env vars and act as defaults (per-Artifact spec can override matching names). When `extraEnvVarsSecret` is also set, it wins for duplicate keys because it appears later in the Pod's `envFrom` list. |
| downloader.hf.disableXet | bool | `false` | Disable the HuggingFace Xet transfer backend cluster-wide by injecting `HF_HUB_DISABLE_XET=1` into every HF download / validation Job. Xet is the default, faster path (chunk-based dedup) and is the upstream-recommended backend, so this defaults to `false`. Set to `true` as a cluster-wide fallback if large downloads stall on this cluster's network (a known Xet failure mode) — it reverts to the classic HTTPS/LFS path, which supports byte-range resume. Applied as a DEFAULT: a per-Artifact `spec.source.huggingface.env` entry for `HF_HUB_DISABLE_XET` overrides it. |
| downloader.image.pullPolicy | string | `"IfNotPresent"` | Downloader image pull policy. |
| downloader.image.repository | string | `"255250787067.dkr.ecr.ap-northeast-2.amazonaws.com/hermod-downloader"` | Downloader image repository. |
| downloader.image.tag | string | `""` | Downloader image tag. Defaults to `Chart.AppVersion` when empty. |
| downloader.job | object | `{"resources":{"requests":{"cpu":"100m","memory":"256Mi"}}}` | Container resources applied to every hermod-spawned Job Pod (check, download, validation, cleanup). Setting at least one `requests` or `limits` entry (on cpu or memory) lifts the Pod QoS class from BestEffort to Burstable — Kubernetes treats either side as sufficient — which keeps the long-running SHA256 hashing on Validation Jobs from being evicted under node pressure.  The downloader containers are I/O-bound (network + SHA256 streaming) so modest requests are enough. Raise these if your cluster's scheduler mis-binpacks smaller Pods.  Set `requests: {}` and `limits: {}` to revert to the previous BestEffort behavior. |
| downloader.maxConcurrentDownloads | int | `3` | Maximum number of concurrent download Jobs (0 = unlimited). |
| downloader.maxStallRestarts | int | `3` | Maximum number of times the controller restarts a single download after it stalls (no progress within `stallWindow`) before marking the Artifact Failed. This breaks an unrecoverable resume loop and surfaces a diagnostic condition/Event naming the likely cause (source unreachable / network lost). `0` (or a negative value) disables the cap (unlimited restarts). Only used when `stallWindow` is greater than 0. |
| downloader.maxWorkers | int | `8` | Number of parallel file download workers per HuggingFace download Job. Passed as `hf download --max-workers`. Increase (e.g. 16–32) on fast networks with large repos; lower (e.g. 2–4) to stay under HF CDN rate limits. `0` (or a negative value) leaves the flag unset and defers to the huggingface_hub library default (8). |
| downloader.s3.defaultProfileName | string | `""` | Name of an `S3Profile` that an S3 Artifact binds to when it names none in `spec.source.s3.profileRef`. Empty (the default) applies no profile, which is how every S3 Artifact behaves without this value set.  Applied by the Artifact defaulting webhook on CREATE only, which writes the name into the Artifact's own spec. Two consequences worth knowing before setting it:    - Artifacts that already exist are untouched, now and later. They were     admitted before this value was set, are never re-admitted, and so keep     an empty `profileRef` that no default can reach. Changing this value     likewise cannot retarget anything already created.   - The named profile must exist before this is set. An S3 Artifact create     is rejected when the name resolves to no `S3Profile`, so setting this     to a name that does not exist blocks new S3 Artifacts.  Nothing verifies the profile's endpoint or credentials until a download Job runs, so create one S3 Artifact against the profile explicitly and let it reach Ready before promoting the profile to the cluster default.  Ignored when `controller.role` is `Secondary`: Artifacts there are mirrors of the Primary's, and a locally-stamped `profileRef` would be rewritten on every mirror sync. |
| downloader.stallSampleInterval | string | `"15m"` | How often the controller samples an in-progress download's size to detect a stall, as a Go duration (e.g. "15m"). Only used when `stallWindow` is greater than 0. |
| downloader.stallWindow | string | `"1h"` | Download stall window, as a Go duration (e.g. "1h", "30m"). If a download makes no progress (its directory does not grow) within this window, the controller restarts the download Job, which resumes from the `.incomplete` marker so no progress is lost. This handles network stalls without a fixed timeout that would kill legitimately long downloads of large models. Set to "0" to disable stall detection. |
| downloader.validation | object | `{"defaultMode":"Full","defaultParallelism":"auto"}` | Cluster-wide defaults for `Artifact.spec.validation`. The controller applies these at Job-build time when `spec.validation` is left unset by the user. The user's spec is preserved as-is; effective values appear in `status.validation.{mode,parallelism}` after the first reconcile. |
| downloader.validation.defaultMode | string | `"Full"` | Default value for `spec.validation.mode`. One of:   - "Full"            : SHA256 vs HF API + safetensors format                         validation.   - "SafetensorsOnly" : skip SHA256, still validate safetensors                         files (format parsing via the official                         library). Use for Xet-only repos or                         extreme-size models where bitwise                         verification is impractical.   - "Skip"            : disable both stages. No integrity                         guarantee; use only when the artifact is                         validated out of band. |
| downloader.validation.defaultParallelism | string | `"auto"` | Default value for `spec.validation.parallelism`. `"auto"` resolves to `min(os.cpu_count() or 4, 8)` inside the validation Job container (the `or 4` handles the rare case where Python cannot read the CPU count from the container). Explicit integer strings in the range "1".."32" override — set "1" for HDD-backed storage where additional workers only add seek contention. |
| fullnameOverride | string | `""` | Full name override. Defaults to `{Release.Name}-{Chart.Name}`. |
| global | object | `{"imagePullSecrets":[]}` | Global values shared across sub-charts (bitnami/common convention). |
| global.imagePullSecrets | list | `[]` | Image pull secrets shared with sub-charts. |
| nameOverride | string | `""` | Chart name override. Defaults to the chart's `name` field. |
| namespaceOverride | string | `""` | Namespace override. Defaults to `.Release.Namespace`. |
| rbacHelpers | object | `{"enabled":false}` | Install helper ClusterRoles for each CRD (admin/editor/viewer). Bind these to your users/groups to delegate Artifact and ArtifactRepository management. |
| secondary | object | `{"mirrorLabelSelector":"","primaryKubeconfigSecret":"","sourceClusterName":""}` | Secondary-role configuration. Ignored when controller.role=Primary. |
| secondary.mirrorLabelSelector | string | `""` | Label selector restricting which Primary Artifacts are mirrored (empty = all). |
| secondary.primaryKubeconfigSecret | string | `""` | Name of a Secret in the install namespace holding the Primary cluster kubeconfig under the "kubeconfig" key. Required when controller.role=Secondary. |
| secondary.sourceClusterName | string | `""` | Identifier recorded in mirror CRs' status.mirror.sourceCluster. |
| serviceAccount | object | `{"annotations":{},"automount":true,"create":true,"name":""}` | ServiceAccount for the operator. |
| serviceAccount.annotations | object | `{}` | Extra annotations on the ServiceAccount. |
| serviceAccount.automount | bool | `true` | Whether to auto-mount the API credentials for the ServiceAccount. |
| serviceAccount.create | bool | `true` | Whether to create a ServiceAccount. |
| serviceAccount.name | string | `""` | ServiceAccount name. When empty and `create=true`, a name is derived from the chart fullname. |

## Source Code

* <https://github.com/moreh-dev/hermod/tree/main/deploy/helm/hermod>
